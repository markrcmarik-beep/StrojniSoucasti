## Funkce Julia
###############################################################
## Popis funkce:
# Vrátí hodnotu dovoleného napětí materiálu.
# ver: 2025-11-06
## Funkce: dovoleneNapeti()
#
## Vzor:
## σ = dovoleneNapeti(Re, N::AbstractString, Z::AbstractString)
## Vstupní proměnné:
# Re - mez kluzu materiálu s jednotkou
# N - druh namáhání jako řetězec: "tah", "tlak", "střih", "ohyb", "krut"
# Z - způsob zatížení jako řetězec: "statický", "pulzní", "dynamický", "rázový"
## Výstupní proměnné:
# σ - dovolené napětí materiálu s jednotkou
## Použité balíčky
# Unitful
## Použité funkce:
# 
## Příklad:
# dovoleneNapeti(250u"MPa", "tah", "statický")
#   vrátí dovolené napětí pro materiál s mezí kluzu 250 MPa při statickém tahu
#   => 192.3076923076923 MPa
###############################################################
## Použité proměnné vnitřní:
#
using Unitful
function dovoleneNapeti(Re, N::AbstractString, Z::AbstractString)
# Ověření jednotek Re
if !(Re isa Unitful.Quantity)
    error("Vstupní parametr Re musí mít jednotku (např. 250u\"MPa\").")
end
# Ověření druhu namáhání
povoleneN = ["tah", "tlak", "střih", "ohyb", "krut"]
if !(N in povoleneN)
    error("Neznámý druh namáhání: $N. Povolené hodnoty: $(join(povoleneN, ", ")).")
end

# Určení bezpečnostního faktoru gammaM podle typu zatížení a namáhání
gammaM = begin
    if Z == "statický"
        if N in ["tah", "tlak"]
            1.3
        elseif N in ["střih", "ohyb"]
            1.5
        elseif N == "krut"
            1.7
        else
            error("Neznámý druh namáhání: $N")
        end
    elseif Z == "pulzní"
        2.5
    elseif Z == "dynamický"
        3.5
    elseif Z == "rázový"
        5.0
    else
        error("Neznámý způsob zatížení: $Z")
    end
end

# Výpočet dovoleného napětí
σ = if N in ["tah", "tlak", "ohyb"]
    Re / gammaM
elseif N in ["střih", "krut"]
    Re / sqrt(3) / gammaM
end

return σ
end
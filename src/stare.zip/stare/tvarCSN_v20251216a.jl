
using Unitful, Unitful.DefaultSymbols

function tvarCSN(inputStr::AbstractString)

    # Normalizace
    s = uppercase(strip(inputStr))
    s = replace(s, r"\s+" => "")

    dims = Dict{Symbol,Any}()

    # -----------------------------------------------------------
    # PLO / OBD
    # -----------------------------------------------------------
    m = match(r"^(PLO|OBD)(\d+)X(\d+)(R(\d+))?$", s)
    if m !== nothing
        profile, a, b, _, r = m.captures

        a = parse(Int, a)
        b = parse(Int, b)
        r = r === nothing ? 0 : parse(Int, r)

        @assert r ≤ min(a,b)/2 "Rádius R=$r mm je příliš velký"

        dims[:info] = profile
        dims[:a] = a * mm
        dims[:b] = b * mm
        dims[:R] = r * mm
        return dims
    end

    # -----------------------------------------------------------
    # KR
    # -----------------------------------------------------------
    m = match(r"^KR(\d+)$", s)
    if m !== nothing
        dims[:info] = "KR"
        dims[:D] = parse(Int, m.captures[1]) * mm
        return dims
    end

    # -----------------------------------------------------------
    # TRKR
    # -----------------------------------------------------------
    m = match(r"^TRKR(\d+)X(\d+)$", s)
    if m !== nothing
        D = parse(Int, m.captures[1])
        t = parse(Int, m.captures[2])

        @assert D > 2t "Neplatná trubka: D ≤ 2t"

        dims[:info] = "TRKR"
        dims[:D] = D * mm
        dims[:t] = t * mm
        dims[:d] = (D - 2t) * mm
        return dims
    end

    # -----------------------------------------------------------
    # 4HR
    # -----------------------------------------------------------
    m = match(r"^4HR(\d+)(R(\d+))?$", s)
    if m !== nothing
        a = parse(Int, m.captures[1])
        r = m.captures[3] === nothing ? 0 : parse(Int, m.captures[3])

        @assert r ≤ a/2 "Rádius R=$r mm je příliš velký"

        dims[:info] = "4HR"
        dims[:a] = a * mm
        dims[:b] = a * mm
        dims[:R] = r * mm
        return dims
    end

    # -----------------------------------------------------------
    # 6HR
    # -----------------------------------------------------------
    m = match(r"^6HR(\d+)$", s)
    if m !== nothing
        s1 = parse(Int, m.captures[1])

        dims[:info] = "6HR"
        dims[:s] = s1 * mm
        dims[:a] = s1 * mm
        dims[:R] = 0mm
        return dims
    end

    # -----------------------------------------------------------
    # TR4HR
    # -----------------------------------------------------------
    m = match(r"^TR4HR(\d+)X(\d+)X(\d+)(R(\d+))?$", s)
    if m !== nothing
        a = parse(Int, m.captures[1])
        b = parse(Int, m.captures[2])
        t = parse(Int, m.captures[3])
        r = m.captures[5] === nothing ? 0 : parse(Int, m.captures[5])

        @assert a > 2t && b > 2t "Tloušťka stěny je příliš velká"
        @assert r ≤ min(a,b)/2 "Rádius R=$r mm je příliš velký"

        dims[:info] = "TR4HR"
        dims[:a] = a * mm
        dims[:b] = b * mm
        dims[:t] = t * mm
        dims[:R] = r * mm
        return dims
    end

    error("Neznámé nebo nepodporované označení profilu: \"$inputStr\"")
end
## Funkce Julia
###############################################################
## Popis funkce:
# Výpočet namáhání v tlaku pro strojní součásti.
# ver: 2025-12-11
## Funkce: namahanitlak()
#
## Vzor:
## vystupni_promenne = namahanitlak(vstupni_promenne)
## Vstupní proměnné:
# - F::Unitful.Quantity nebo Number : Zatěžující síla (N)
# - S::Unitful.Quantity nebo Number : Plocha průřezu (mm²)
# - sigmaDt::Unitful.Quantity nebo Number : Dovolené napětí v tlaku (MPa)
# - E::Unitful.Quantity nebo Number : Modul pružnosti v tlaku, Youngův modul (GPa), výchozí 210 GPa
## Výstupní proměnné:
# VV - Dict s výsledky výpočtu namáhání v tlaku. Pole VV obsahují:
#   :info - Popis výpočtu
#   :zatizeni - Typ zatížení (statický, dynamický, rázový)
#   :F - Zatěžující síla (Unitful.Quantity)
#   :F_info - Popis pole F
#   :S - Plocha průřezu (Unitful.Quantity)
#   :S_text - Textový popis výpočtu S (je-li k dispozici)
#   :S_info - Popis pole S
#   :sigmaDt - Dovolené napětí v tlaku (Unitful.Quantity)
#   :sigmaDt_info - Popis pole sigmaDt
#   :sigma - Skutečné napětí v tlaku (Unitful.Quantity v MPa)
#   :sigma_info - Popis pole sigma
#   :epsilon - Poměrné zkrácení (bez jednotky)
#   :epsilon_info - Popis pole epsilon
#   :bezpecnost - Součinitel bezpečnosti k (bez jednotky)
#   :bezpecnost_info - Popis pole bezpecnost
#   :verdict - Závěr o bezpečnosti spoje (řetězec)
#   :verdict_info - Popis pole verdict
#   :E - Modul pružnosti v tlaku, Youngův modul (Unitful.Quantity)
#   :E_info - Popis pole E
#   :Re - Mez kluzu (Unitful.Quantity)
#   :Re_info - Popis pole Re
#   :mat - Materiál (řetězec)
#   :mat_info - Popis pole mat
#   :L0 - Délka namáhaného profilu (Unitful.Quantity)
#   :L0_info - Popis pole L0
#   :deltaL - Skutečné prodloužení (Unitful.Quantity), je-li spočítané
#   :deltaL_info - Popis pole deltaL
#   :L - Délka po prodloužení (Unitful.Quantity), je-li spočítané
#   :L_info - Popis pole L
#   :profil - Tvar profilu (řetězec), jestli byl zadaný
#   :profil_info - Popis pole profil
# txt - Volitelně i textový výpis výpočtu. Je-li parametr 
#   return_text=true (výchozí). Pokud return_text=false, vrací 
#   se pouze VV.
## Použité balíčky
# Unitful, Unitful.DefaultSymbols, Printf (jen @sprintf)
## Použité uživatelské funkce:
# materialy, dovoleneNapeti, tvarprofilu
## Příklad:
# namahanitlak(F=1000u"N", S=50u"mm^2", mat="11373")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
# namahanitlak(F=2000, S=100, sigmaDt=150u"MPa", E=200u"GPa", L0=500u"mm", 
#   zatizeni="statický", profil="PLO 20x10")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
###############################################################
## Použité proměnné vnitřní:
#
using Unitful, Unitful.DefaultSymbols
using Printf: @sprintf

function namahanitlak(; 
    F=nothing, S=nothing, sigmaDt=nothing, 
    E=nothing, Re=nothing, L0=nothing, mat=nothing,
    zatizeni::AbstractString="statický", 
    profil=nothing, tvar=nothing,
    return_text::Bool=true)

    # pomocné funkce
    hasq(x) = x !== nothing && isa(x, Unitful.AbstractQuantity)
    isnum(x) = x !== nothing && isa(x, Number)
    attach_unit(x, u) = isa(x, Unitful.AbstractQuantity) ? x : x*u

    # výchozí E
    E_default = 210u"GPa"

    # kontrola duplicity
    cntS = (S !== nothing ? 1 : 0) + (profil !== nothing ? 1 : 0) + (tvar !== nothing ? 1 : 0)
    if cntS > 1
        error("Zadejte pouze jednu z hodnot: S, profil nebo tvar.")
    end

    if sigmaDt !== nothing && mat !== nothing
        error("Zadejte pouze jednu z hodnot: sigmaDt nebo mat.")
    end

    # doplnění jednotek
    if F !== nothing
        if isnum(F)
            F = attach_unit(F, u"N")
        elseif !hasq(F)
            error("Hodnota F musí být číslo nebo Unitful.Quantity.")
        end
    end

    if S !== nothing
        if isnum(S)
            S = attach_unit(S, u"mm^2")
        elseif !hasq(S)
            error("Hodnota S musí být číslo nebo Unitful.Quantity.")
        end
    end

    if sigmaDt !== nothing
        if isnum(sigmaDt)
            sigmaDt = attach_unit(sigmaDt, u"MPa")
        elseif !hasq(sigmaDt)
            error("Hodnota sigmaDt musí být číslo nebo Unitful.Quantity.")
        end
    end

    if Re !== nothing
        if isnum(Re)
            Re = attach_unit(Re, u"MPa")
        elseif !hasq(Re)
            error("Hodnota Re musí být číslo nebo Unitful.Quantity.")
        end
    end

    if E !== nothing
        if isnum(E)
            E = attach_unit(E, u"GPa")
        elseif !hasq(E)
            error("Hodnota E musí být číslo nebo Unitful.Quantity.")
        end
    else
        E = E_default
    end

    if L0 !== nothing
        if isnum(L0)
            L0 = attach_unit(L0, u"mm")
        elseif !hasq(L0)
            error("Hodnota L0 musí být číslo nebo Unitful.Quantity.")
        end
    end

    # materiál → Re a E
    if mat !== nothing
        matinfo_raw = materialy(mat)

        if isa(matinfo_raw, Tuple) && length(matinfo_raw) == 2
            matinfo, _ = matinfo_raw
        elseif isa(matinfo_raw, Dict)
            matinfo = matinfo_raw
        else
            error("materialy(mat) musí vracet Dict nebo (Dict, String).")
        end

        haskey(matinfo, :Re) && (Re = matinfo[:Re])
        haskey(matinfo, :E)  && (E  = matinfo[:E])
    end

    # pokud je Re → sigmaDt přes dovoleneNapeti(Re,"tlak",zatizeni)
    if Re !== nothing
        sigmaDt = dovoleneNapeti(Re, "tlak", zatizeni)
    end

    # profil/tvar
    S_text = ""
    if profil !== nothing
        p = profil(profil)
        haskey(p, :S) || error("profil(...) neobsahuje pole :S")
        S = p[:S]
    elseif tvar !== nothing
        tv = tvar(tvar)
        haskey(tv, :S) || error("tvar(...) neobsahuje pole :S")
        S = tv[:S]
        S_text = get(tv, :S_str, "")
    end

    # kontrola, zda máme vše
    F === nothing && error("Chybí zatěžující síla F.")
    S === nothing && error("Chybí plocha S.")
    sigmaDt === nothing && error("Chybí sigmaDt (dovolené napětí v tlaku).")

    # Výpočet σ = F / S
    sigma = uconvert(u"MPa", F / S)

    # součinitel bezpečnosti k = sigmaDt / sigma
    k = uconvert(u"MPa", sigmaDt) / sigma

    # epsilon = sigma / E (v Pa)
    sigma_pa = uconvert(u"Pa", F / S)
    E_pa = uconvert(u"Pa", E)
    epsilon = sigma_pa / E_pa

    # deltaL a L
    deltaL = L0 === nothing ? nothing : epsilon * L0
    L = L0 === nothing ? nothing : (L0 + deltaL)

    # verdikt
    verdict = if k >= 1.5
        "Spoj je bezpečný"
    elseif k >= 1.0
        "Spoj je na hranici bezpečnosti"
    else
        "Spoj není bezpečný!"
    end

    # výstupní struktura
    VV = Dict{Symbol,Any}()
    VV[:info] = "namáhání v tlaku" # popis výpočtu
    VV[:zatizeni] = zatizeni # typ zatížení
    VV[:F] = F # zatěžující síla
    VV[:F_info] = "Zatěžující síla"
    VV[:S] = S # plocha průřezu
    VV[:S_text] = S_text # vzorec výpočtu S
    VV[:S_info] = "Plocha průřezu profilu"
    VV[:sigmaDt] = sigmaDt # dovolené napětí v tlaku
    VV[:sigmaDt_info] = "Dovolené napětí v tlaku"
    VV[:sigma] = sigma # skutečné napětí v tlaku
    VV[:sigma_info] = "Napětí v tlaku"
    VV[:epsilon] = epsilon # poměrné zkrácení (bez jednotky)
    VV[:epsilon_info] = "Poměrné zkrácení"
    VV[:bezpecnost] = k # součinitel bezpečnosti
    VV[:bezpecnost_info] = "Součinitel bezpečnosti"
    VV[:verdict] = verdict # závěr o bezpečnosti spoje
    VV[:verdict_info] = "Bezpečnost spoje"
    VV[:E] = E # Modul pružnosti v tlaku
    VV[:E_info] = "Modul pružnosti v tlaku"
    VV[:Re] = Re # Mez kluzu
    VV[:Re_info] = "Mez kluzu"
    VV[:mat] = mat # materiál
    VV[:mat_info] = "Materiál"
    VV[:L0] = L0 # Délka namáhaného profilu
    VV[:L0_info] = "Délka namáhaného profilu"
    VV[:deltaL] = deltaL # Zkrácení (je-li spočítané)
    VV[:deltaL_info] = deltaL===nothing ? "" : "Skutečné zkrácení"
    VV[:L] = L # Délka po deformaci
    VV[:L_info] = L===nothing ? "" : "Délka po deformaci"
    VV[:profil] = profil === nothing ? "" : profil # profil (pokud byl zadaný)
    VV[:profil_info] = "Tvar profilu"
    
    if return_text
        Dispstr = namahanitlaktext(VV) # formátovaný textový výstup
        return VV, Dispstr
    else
        return VV
    end
    #return return_text ? (VV, namahanitlaktext(VV)) : VV
end

# textový výstup
function namahanitlaktext(VV::Dict{Symbol,Any})
    lines = String[]

    push!(lines, "Výpočet $(VV[:info])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "materiál: $(VV[:mat] === nothing ? "" : VV[:mat])")
    push!(lines, "profil: $(VV[:profil])")
    push!(lines, "zatížení: $(VV[:zatizeni])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "zadání:")

    # F
    if VV[:F] !== nothing
        v = uconvert(u"N", VV[:F]) # převod na N
        push!(lines, @sprintf("F = %g N   %s", ustrip(u"N", v), VV[:F_info]))
    end

    # S
    if VV[:S] !== nothing
        v = uconvert(u"mm^2", VV[:S]) # převod na mm^2
        if VV[:S_text] != ""
            push!(lines, @sprintf("S = %s = %g mm^2   %s",
                VV[:S_text], ustrip(u"mm^2", v), VV[:S_info]))
        else
            push!(lines, @sprintf("S = %g mm^2   %s",
                ustrip(u"mm^2", v), VV[:S_info]))
        end
    end

    # sigmaDt
    if VV[:sigmaDt] !== nothing
        v = uconvert(u"MPa", VV[:sigmaDt]) # převod na MPa
        push!(lines, @sprintf("sigmaDt = %g MPa   %s",
            ustrip(u"MPa", v), VV[:sigmaDt_info]))
    end

    # L0
    if VV[:L0] !== nothing
        v = uconvert(u"mm", VV[:L0]) # převod na mm
        push!(lines, @sprintf("L0 = %g mm   %s",
            ustrip(u"mm", v), VV[:L0_info]))
    end

    # Re
    if VV[:Re] !== nothing
        v = uconvert(u"MPa", VV[:Re]) # převod na MPa
        push!(lines, @sprintf("Re = %g MPa   %s",
            ustrip(u"MPa", v), VV[:Re_info]))
    end

    # E
    if VV[:E] !== nothing
        v = uconvert(u"GPa", VV[:E]) # převod na GPa
        push!(lines, @sprintf("E = %g GPa   %s",
            ustrip(u"GPa", v), VV[:E_info]))
    end

    push!(lines, "----------------------------------------------------------------")
    push!(lines, "výpočet:")

    # sigma
    sig = uconvert(u"MPa", VV[:sigma]) # převod na MPa
    push!(lines, @sprintf("sigma = %g MPa   %s",
        ustrip(u"MPa", sig), VV[:sigma_info]))

    # epsilon
    eps = VV[:epsilon]
    push!(lines, @sprintf("epsilon = %g = %g %%   %s",
        eps, eps*100, VV[:epsilon_info]))

    # deltaL
    if VV[:deltaL] !== nothing
        v = uconvert(u"mm", VV[:deltaL])
        push!(lines, @sprintf("deltaL = %g mm   %s",
            ustrip(u"mm", v), VV[:deltaL_info]))
    end

    # L
    if VV[:L] !== nothing
        v = uconvert(u"mm", VV[:L])
        push!(lines, @sprintf("L = %g mm   %s",
            ustrip(u"mm", v), VV[:L_info]))
    end

    # bezpečnost
    k = VV[:bezpecnost]
    push!(lines, @sprintf("k = %g   %s\n%s:  %s",
        ustrip(k), VV[:bezpecnost_info],
        VV[:verdict_info], VV[:verdict]))

    return join(lines, "\n")
end
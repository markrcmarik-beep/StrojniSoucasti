## Funkce Julia
###############################################################
## Popis funkce:
# Výpočet namáhání v tahu pro strojní součásti.
# ver: 2025-12-10
## Funkce: namahanitah()
#
## Vzor:
## vystupni_promenne = namahanitah(vstupni_promenne)
## Vstupní proměnné:
# - F::Unitful.Quantity nebo Number : Zatěžující síla (N)
# - S::Unitful.Quantity nebo Number : Plocha průřezu (mm²)
# - sigmaDt::Unitful.Quantity nebo Number : Dovolené napětí v tahu (MPa)
# - E::Unitful.Quantity nebo Number : Modul pružnosti v tahu, Youngův modul (GPa), výchozí 210 GPa
## Výstupní proměnné:
# VV - Dict s výsledky výpočtu namáhání v tahu. Pole VV obsahují:
#   :info - Popis výpočtu
#   :zatizeni - Typ zatížení (statický, dynamický, rázový)
#   :F - Zatěžující síla (Unitful.Quantity)
#   :F_info - Popis pole F
#   :S - Plocha průřezu (Unitful.Quantity)
#   :S_text - Textový popis výpočtu S (je-li k dispozici)
#   :S_info - Popis pole S
#   :sigmaDt - Dovolené napětí v tahu (Unitful.Quantity)
#   :sigmaDt_info - Popis pole sigmaDt
#   :sigma - Skutečné napětí v tahu (Unitful.Quantity v MPa)
#   :sigma_info - Popis pole sigma
#   :epsilon - Poměrné prodloužení (bez jednotky)
#   :epsilon_info - Popis pole epsilon
#   :bezpecnost - Součinitel bezpečnosti k (bez jednotky)
#   :bezpecnost_info - Popis pole bezpecnost
#   :verdict - Závěr o bezpečnosti spoje (řetězec)
#   :verdict_info - Popis pole verdict
#   :E - Modul pružnosti v tahu, Youngův modul (Unitful.Quantity)
#   :E_info - Popis pole E
#   :Re - Mez kluzu (Unitful.Quantity)
#   :Re_info - Popis pole Re
#   :mat - Materiál (řetězec)
#   :mat_info - Popis pole mat
#   :L0 - Délka namáhaného profilu (Unitful.Quantity)
#   :L0_info - Popis pole L0
#   :deltaL - Skutečné prodloužení (Unitful.Quantity), je-li spočítané
#   :deltaL_info - Popis pole deltaL
#   :L - Délka po prodloužení (Unitful.Quantity), je-li spočítané
#   :L_info - Popis pole L
#   :profil - Tvar profilu (řetězec), jestli byl zadaný
#   :profil_info - Popis pole profil
# txt - Volitelně i textový výpis výpočtu. Je-li parametr 
#   return_text=true (výchozí). Pokud return_text=false, vrací 
#   se pouze VV.
## Použité balíčky
# Unitful, Unitful.DefaultSymbols, Printf (jen @sprintf)
## Použité uživatelské funkce:
# materialy, dovoleneNapeti, profil, tvar
## Příklad:
# namahanitah(F=1000u"N", S=50u"mm^2", mat="11373")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
# namahanitah(F=2000, S=100, sigmaDt=150u"MPa", E=200u"GPa", L0=500u"mm", 
#   zatizeni="statický", profil="PLO 20x10")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
###############################################################
## Použité proměnné vnitřní:
#
using Unitful, Unitful.DefaultSymbols
using Printf: @sprintf

function namahanitah(; F=nothing, S=nothing, sigmaDt=nothing, 
    E=nothing, Re=nothing, L0=nothing, mat=nothing, 
    zatizeni::AbstractString="statický", profil=nothing, 
    tvar=nothing, return_text::Bool=true)

    # pomocné
    hasq(x) = x !== nothing && x !== missing && isa(x, 
    Unitful.AbstractQuantity)
    isnum(x) = x !== nothing && isa(x, Number)
    attach_unit(x, u) = isa(x, Unitful.AbstractQuantity) ? x : x * u

    # výchozí E (Young) — standardně 210 GPa
    E_default = 210u"GPa" # výchozí hodnota E

    # kontroly duplicity volby S/profil/tvar a sigmaDt/mat
    cntS = (S !== nothing ? 1 : 0) + (profil !== nothing ? 1 : 0) + 
    (tvar !== nothing ? 1 : 0)
    if cntS > 1
        error("Zadejte pouze jednu z hodnot: S, profil nebo tvar.")
    end
    if (sigmaDt !== nothing) && (mat !== nothing)
        error("Zadejte pouze jednu z hodnot: sigmaDt nebo mat.")
    end

    # doplnění jednotek pro číselné vstupy
    if F !== nothing
        if isnum(F)
            F = attach_unit(F, u"N") # přiřazení jednotky N
        elseif !hasq(F)
            error("Neznámý formát F: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if S !== nothing
        if isnum(S)
            S = attach_unit(S, u"mm^2")   # přiřazení jednotky mm^2
        elseif !hasq(S)
            error("Neznámý formát S: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if sigmaDt !== nothing
        if isnum(sigmaDt)
            sigmaDt = attach_unit(sigmaDt, u"MPa") # přiřazení jednotky MPa
        elseif !hasq(sigmaDt)
            error("Neznámý formát sigmaDt: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if Re !== nothing
        if isnum(Re)
            Re = attach_unit(Re, u"MPa")  # přiřazení jednotky MPa
        elseif !hasq(Re)
            error("Neznámý formát Re: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if E !== nothing
        if isnum(E)
            E = attach_unit(E, u"GPa") # přiřazení jednotky GPa
        elseif !hasq(E)
            error("Neznámý formát E: očekávám číslo nebo Unitful.Quantity")
        end
    else
        E = E_default
    end

    if L0 !== nothing
        if isnum(L0)
            L0 = attach_unit(L0, u"mm") # přiřazení jednotky mm
        elseif !hasq(L0)
            error("Neznámý formát L0: očekávám číslo nebo Unitful.Quantity")
        end
    end

    # pokud je zadán materiál, pokusíme se získat Re/E z materialy(mat)
    if mat !== nothing
        if !isa(mat, AbstractString)
            error("Argument 'mat' musí být řetězec s názvem materiálu.")
        end
        # očekáváme, že uživatel má definovanou funkci materialy(mat::String)
        if !isdefined(Main, :materialy)
            error("Funkce `materialy(mat)` není definována v Main. Definujte ji nebo neposílejte 'mat'.")
        end
        # matinfo = materialy(mat) # očekává Dict nebo objekt s poli :Re a :E (Unitful)
        matinfo_raw = materialy(mat)

if isa(matinfo_raw, Tuple) && length(matinfo_raw) == 2
    matinfo, _ = matinfo_raw              # 1. Dict, 2. text
elseif isa(matinfo_raw, Dict)
    matinfo = matinfo_raw                 # čistý Dict
else
    error("materialy(mat) musí vracet Dict nebo (Dict, String).")
end
        if haskey(matinfo, :Re)
            Re = matinfo[:Re]
        end
        if haskey(matinfo, :E)
            E = matinfo[:E]
        end
    end

    # pokud je zadané Re -> spočítat sigmaDt pomocí dovoleneNapeti
    if Re !== nothing
        if !isdefined(Main, :dovoleneNapeti)
            error("Funkce `dovoleneNapeti(Re, typ, zatizeni)` není definována v Main, ale 'Re' byl zadán.")
        end
        sigmaDt = dovoleneNapeti(Re, "tah", zatizeni)
    end

    # pokud je zadán profil/tvar, zavolat externí funkce, aby dodaly S (a text)
    S_text = ""
    if profil !== nothing
        if !isdefined(Main, :profil)
            error("Funkce `profil(...)` není definována, ale 'profil' byl zadán.")
        end
        # očekáváme, že profil(profilname, "S") vrátí Dict(:S => quantity)
        p = profil(profil)
        if haskey(p, :S)
            S = p[:S] # plocha průřezu
        else
            error("profil(...) neobsahuje pole :S")
        end
    elseif tvar !== nothing
        if !isdefined(Main, :tvar)
            error("Funkce `tvar(...)` není definována, ale 'tvar' byl zadán.")
        end
        tv = tvar(tvar) # očekáváme, že tvar(tvarname) vrátí Dict(:S => quantity, :S_str => string)
        if haskey(tv, :S)
            S = tv[:S] # plocha průřezu
        else
            error("tvar(...) neobsahuje pole :S")
        end
        if haskey(tv, :S_str)
            S_text = tv[:S_str]
        end
    end

    # finální kontrola, že máme F, S, sigmaDt
    if F === nothing
        error("Chybí zatěžující síla F.")
    end
    if S === nothing
        error("Chybí plocha S (nebo profil / tvar).")
    end
    if sigmaDt === nothing
        error("Chybí sigmaDt (dovolené napětí) — zadejte 'sigmaDt' nebo 'Re' či 'mat'.")
    end

    # výpočet: sigma = F / S -> převod na MPa
    sigma = F / S
    sigma_mpa = uconvert(u"MPa", sigma)

    # součinitel bezpečnosti k = sigmaDt / sigma (oba v MPa)
    sigmaDt_mpa = uconvert(u"MPa", sigmaDt)
    k = sigmaDt_mpa / sigma_mpa      # je to Unitful.Quantity bez jednotky

    # epsilon = sigma / E  (bez jednotky)
    # uconvert E na stejnou jednotku jako sigma (MPa -> GPa případně), ale raději převedeme sigma do Pa a E do Pa
    E_pa = uconvert(u"Pa", E)
    sigma_pa = uconvert(u"Pa", sigma)
    epsilon = sigma_pa / E_pa  # bez jednotky

    # deltaL a L pokud L0 zadané
    deltaL = nothing
    L = nothing
    if L0 !== nothing
        # epsilon je bez jednotky, L0 má jednotku mm — deltaL má jednotku mm
        deltaL = epsilon * L0
        L = L0 + deltaL
    end

    # verdict podle k
    verdict = if k >= 1.5
        "Spoj je bezpečný"
    elseif k >= 1.0
        "Spoj je na hranici bezpečnosti"
    else
        "Spoj není bezpečný!"
    end

    # připravíme výstupní dict (VV)
    VV = Dict{Symbol,Any}()
    VV[:info] = "namáhání v tahu"
    VV[:zatizeni] = zatizeni # typ zatížení
    VV[:F] = F # zatěžující síla
    VV[:F_info] = "Zatěžující síla"
    VV[:S] = S # plocha průřezu
    VV[:S_text] = S_text # vzorec výpočtu S
    VV[:S_info] = "Plocha průřezu profilu"
    VV[:sigmaDt] = sigmaDt # dovolené napětí v tahu
    VV[:sigmaDt_info] = "Dovolené napětí v tahu"
    VV[:sigma] = sigma_mpa # skutečné napětí v MPa
    VV[:sigma_info] = "Napětí v tahu"
    VV[:epsilon] = epsilon # poměrné prodloužení (bez jednotky)
    VV[:epsilon_info] = "Poměrné prodloužení"
    VV[:bezpecnost] = k # součinitel bezpečnosti k (bez jednotky)
    VV[:bezpecnost_info] = "Součinitel bezpečnosti"
    VV[:verdict] = verdict # závěr o bezpečnosti spoje
    VV[:verdict_info] = "Bezpečnost spoje"
    VV[:E] = E # modul pružnosti
    VV[:E_info] = "Modul pružnosti v tahu, Youngův modul"
    VV[:Re] = Re # mez kluzu
    VV[:Re_info] = "Mez kluzu"
    VV[:mat] = mat # materiál
    VV[:mat_info] = "Materiál"
    VV[:L0] = L0 # počáteční délka
    VV[:L0_info] = "Délka namáhaného profilu"
    VV[:deltaL] = deltaL # prodloužení (je-li spočítané)
    VV[:deltaL_info] = deltaL === nothing ? "" : "Skutečné prodloužení"
    VV[:L] = L # konečná délka (je-li spočítané)
    VV[:L_info] = L === nothing ? "" : "Délka po prodloužení"
    VV[:profil] = profil === nothing ? "" : profil # profil (jestli byl zadaný)
    VV[:profil_info] = "Tvar profilu"

    if return_text
        Dispstr = namahanitahtext(VV) # formátovaný textový výstup
        return VV, Dispstr
    else
        return VV
    end
end

# pomocná funkce pro formátování výstupu (podobná MATLAB verzi)
function namahanitahtext(VV::Dict{Symbol,Any})
    lines = String[] # pole řetězců pro výstup
    push!(lines, "Výpočet $(VV[:info])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "materiál: $(VV[:mat] === nothing ? "" : string(VV[:mat]))")
    push!(lines, "profil: $(VV[:profil])")
    push!(lines, "zatížení: $(VV[:zatizeni])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "zadání:")

    # F
    if VV[:F] !== nothing
        Fval = uconvert(u"N", VV[:F]) # převod na N
        push!(lines, @sprintf(
            "F = %g %s   %s",
            ustrip(u"N", Fval), "N", VV[:F_info]
        ))
    end

    # S
    if VV[:S] !== nothing
        Sval = uconvert(u"mm^2", VV[:S]) # převod na mm^2
        if VV[:S_text] != ""
            push!(lines, @sprintf(
                "S = %s = %g %s   %s",
                VV[:S_text],
                ustrip(u"mm^2", Sval), "mm^2",
                VV[:S_info]
            ))
        else
            push!(lines, @sprintf(
                "S = %g %s   %s",
                ustrip(u"mm^2", Sval), "mm^2",
                VV[:S_info]
            ))
        end
    end

    # sigmaDt
    if VV[:sigmaDt] !== nothing
        sd = uconvert(u"MPa", VV[:sigmaDt]) # převod na MPa
        push!(lines, @sprintf(
            "sigmaDt = %g %s   %s",
            ustrip(u"MPa", sd), "MPa", VV[:sigmaDt_info]
        ))
    end

    # L0
    if VV[:L0] !== nothing
        L0v = uconvert(u"mm", VV[:L0]) # převod na mm
        push!(lines, @sprintf(
            "L0 = %g %s   %s",
            ustrip(u"mm", L0v), "mm", VV[:L0_info]
        ))
    end

    # Re
    if VV[:Re] !== nothing
        Rv = uconvert(u"MPa", VV[:Re]) # převod na MPa
        push!(lines, @sprintf(
            "Re = %g %s   %s",
            ustrip(u"MPa", Rv), "MPa", VV[:Re_info]
        ))
    end

    # E
    if VV[:E] !== nothing
        Ev = uconvert(u"GPa", VV[:E]) # převod na GPa
        push!(lines, @sprintf(
            "E = %g %s   %s",
            ustrip(u"GPa", Ev), "GPa", VV[:E_info]
        ))
    end

    push!(lines, "----------------------------------------------------------------")
    push!(lines, "výpočet:")

    # sigma
    s = uconvert(u"MPa", VV[:sigma]) # převod na MPa
    push!(lines, @sprintf(
        "sigma = %g %s   %s",
        ustrip(u"MPa", s), "MPa", VV[:sigma_info]
    ))

    # epsilon
    eps = VV[:epsilon] # bez jednotky
    push!(lines, @sprintf("epsilon = %g = %g %%   %s",
        eps, eps * 100, VV[:epsilon_info]))

    # deltaL
    if VV[:deltaL] !== nothing
        dl = uconvert(u"mm", VV[:deltaL]) # převod na mm
        push!(lines, @sprintf(
            "deltaL = %g %s   %s",
            ustrip(u"mm", dl), "mm", VV[:deltaL_info]
        ))
    end

    # L
    if VV[:L] !== nothing
        L = uconvert(u"mm", VV[:L]) # převod na mm
        push!(lines, @sprintf(
            "L = %g %s   %s",
            ustrip(u"mm", L), "mm", VV[:L_info]
        ))
    end

    # bezpečnost
    k = VV[:bezpecnost] # bez jednotky
    push!(lines, @sprintf(
        "k = %g   %s\n%s:  %s",
        ustrip(k),
        VV[:bezpecnost_info],
        VV[:verdict_info],
        VV[:verdict]
    ))

    return join(lines, "\n") # spojení řádků do jednoho řetězce
end
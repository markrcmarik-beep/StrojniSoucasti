## Funkce Julia
###############################################################
## Popis funkce:
# Vrátí vlastnosti hledaného materiálu dle tabulky
# ver: 2025-11-05
## Funkce: materialy()
#
## Vzor:
## B, C = materialy(A)
## Vstupní proměnné:
# A - Hledaný materiál. [string]
## Výstupní proměnné:
# B - Pole hodnot, vlastností. [struct]
#  .E - Modul pružnosti v tahu, Youngův modul [GPa] [symunit]
#  .G - Modul pružnosti v krutu [GPa] [symunit]
#  .Re - Mez kluzu [MPa] [symunit]
#  .Rm - Mez pevnosti [MPa] [symunit]
#  .sigmae -  Mez únavy v tahu/tlaku [MPa] [symunit]
#  .sigmadt -  Dovolené napětí v tahu [MPa] [symunit]
#  .sigmadk -  Dovolené napětí v tlaku [MPa] [symunit]
#  .taues -  Mez únavy ve smyku [MPa] [symunit]
#  .tauds -  Dovolené napětí ve smyku - střihu [MPa] [symunit]
#  .taueo -  Mez únavy v ohybu [MPa] [symunit]
#  .taudo -  Dovolené napětí v ohybu [MPa] [symunit]
#  .tauek -  Mez únavy v krutu [MPa] [symunit]
#  .taudk -  Dovolené napěti v krutu [MPa] [symunit]
#  .pd - Dovolené napětí na otlačení [MPa] [symunit]
#  .rho - Hustota materiálu [[kg]/[m]^3] [symunit]
#  .alfa - Koeficient tepelné lineární roztažnosti [1/[Celsius] [symunit]
# C - Výpis hodnot char
## Použité balíčky
# SpravaSouboru
## Použité funkce:
# sprdsheet2velkst(), sprsheetRef(), sprsheet2tabl()
## Příklad:
#
###############################################################
## Použité proměnné vnitřní:
#
using SpravaSouboru
using Unitful
function materialy(A::AbstractString; tisk::Bool=false)
  cesta01 = dirname(@__FILE__)  # cesta k této funkci
  podslozka = "materialy"       # podsložka s materiály a daty
  soubor1 = "materialy.ods"     # hlavní soubor s daty (.ods)
  souborDat = "materialy.jld2"  # záložní data (.jld2) pro rychlejší načítání
  listname = "material"         # název listu v souboru s daty
  STRTradk = 3                  # řádek, kde začínají data

  # zjistit rozsah listu
  rozsah = sprdsheet2velkst(joinpath(cesta01, podslozka, soubor1), listname) # např. "A1:L100"
  koncova_adresa = last(split(rozsah, ':')) # např. "L100" nebo "A50" atd.
  W1 = sprsheetRef(koncova_adresa) # např. ["L", "100"]
  W1_nova = sprsheetRef([STRTradk, W1[2]]) # např. ["L", "3"]
  rozsahNadpis = "A$(STRTradk):$W1_nova" # např. "A3:L3"
  rozsahTabulka = "A5:$koncova_adresa" # např. "A5:L100"

  # načteme nadpisy a tabulku
  hdr_mat, _, raw_tbl = sprsheet2tabl(joinpath(cesta01, podslozka), [soubor1, souborDat], listname, [rozsahNadpis, rozsahNadpis, rozsahTabulka])
  headers = vec(hdr_mat) # převést na vektor (ze 1xN matice)

  # sanitizovat názvy sloupců -> symboly
  function sanitize_header(s)
    s2 = replace(string(s), r"\s+" => "_") # mezery na podtržítka
    s2 = replace(s2, r"[^A-Za-z0-9_]" => "_") # nepovolené znaky na podtržítka
    if isempty(s2) # prázdný název sloupce
      s2 = "col" # prázdný název sloupce nahradit "col"
    end
    if occursin(r"^[0-9]", s2) # začíná číslem
      s2 = "_" * s2 # pokud začíná číslem, přidat podtržítko na začátek 
    end
    return Symbol(s2)
  end

  col_syms = [sanitize_header(h) for h in headers]

  # raw_tbl může být v případě jednoho sloupce vektorem
  if ndims(raw_tbl) == 1
    raw_tbl = reshape(raw_tbl, :, 1) # převést na matici s jedním sloupcem
  end
  nrows, ncols = size(raw_tbl) # počet řádků a sloupců v tabulce
  cols = [raw_tbl[:, j] for j in 1:ncols] # extrahovat jednotlivé sloupce jako vektory

  TBL = (; Pair.(col_syms, cols)...) # vytvořit NamedTuple z vektorů sloupců

  # Funkce pro hledání řádku podle hodnoty ve sloupci (ignoruje mezery a case)
  function find_row_by_value(vec, val)
    for (i, x) in enumerate(vec) # procházet všechny hodnoty ve sloupci
      xs = lowercase(replace(string(x), " " => "")) # odstranit mezery a převést na lowercase
      if xs == lowercase(replace(val, " " => "")) # porovnat s hledanou hodnotou
        return i # vrátit index řádku, pokud nalezeno
      end
    end
    return nothing # pokud nenalezeno, vrátit nothing
  end

  # Hledáme v několika sloupcích
  row = nothing # nalezený řádek (nebo nothing)
  for key in (:CSN, :ISO, :DIN, :EN, :znacka) # klíče k prohledání
    if haskey(TBL, key) # pokud sloupec existuje v tabulce
      r = find_row_by_value(TBL[key], A) # hledat řádek s hodnotou A ve sloupci key
      if r !== nothing # pokud nalezeno
        row = r
        break # ukončit hledání
      end
    end
  end
  if row === nothing # pokud nebyl nalezen žádný řádek
    error("Zadaný materiál -- $A -- nebyl nalezen.") # pokud nenalezen, vyhodit chybu
  end

  # zkopíruj hodnoty do Dict B
  B = Dict{String,Any}()
  function set_if_present(sym, name) # pomocná funkce pro nastavení hodnoty v B
    if haskey(TBL, sym) && !ismissing(TBL[sym][row]) && !isempty(string(TBL[sym][row])) # pokud hodnota existuje a není missing nebo prázdná
      B[name] = TBL[sym][row]
    end
  end
  # načtení hodnot do B
  set_if_present(:CSN, "CSN")
  set_if_present(:ISO, "ISO")
  set_if_present(:DIN, "DIN")
  set_if_present(:EN, "EN")
  set_if_present(:znacka, "znacka")
  set_if_present(:ny, "ny")
  set_if_present(:E, "E")
  set_if_present(:G, "G")
  set_if_present(:Re, "Re")
  set_if_present(:Rm, "Rm")
  set_if_present(:rho, "rho")
  set_if_present(:alfa, "alfa")
  set_if_present(:popis, "popis")
  set_if_present(:stav, "stav")

  # převod na fyzikální jednotky
  if haskey(B, "E")
    B["E"] = B["E"] * u"GPa"
  end
  if haskey(B, "G")
    B["G"] = B["G"] * u"GPa"
  end
  if haskey(B, "Re")
    B["Re"] = B["Re"] * u"MPa"
  end
  if haskey(B, "Rm")
    B["Rm"] = B["Rm"] * u"MPa"
  end
  if haskey(B, "rho")
    B["rho"] = B["rho"] * u"kg/m^3"
  end
  if haskey(B, "alfa")
    B["alfa"] = B["alfa"] * u"1/°C"
  end
  # odvozené hodnoty (jednoduché poměry podle MATLAB skriptu)
  if haskey(B, "Rm") && !haskey(B, "Re")
    B["sigmae"] = B["Rm"] * 0.4 # mez únavy v tahu/tlaku
    B["taues"] = B["Rm"] * 0.23 # mez únavy ve smyku
    B["tauek"] = B["Rm"] * 0.23 # mez únavy v krutu
    B["taueo"] = B["Rm"] * 0.4 # mez únavy v ohybu
  end
  if haskey(B, "Re") && !haskey(B, "Rm")
    B["sigmae"] = B["Re"] * 0.4 # mez únavy v tahu/tlaku
    B["sigmadt"] = B["Re"] * 0.8 # dovolené napětí v tahu
    B["sigmadk"] = B["Re"] * 0.8 # dovolené napětí v tlaku
    B["taues"] = B["Re"] * 0.23 # mez únavy ve smyku
    B["tauds"] = B["Re"] * 0.25 # dovolené napětí ve smyku - střihu
    B["taueo"] = B["Re"] * 0.4 # mez únavy v ohybu
    B["taudo"] = B["Re"] * 0.4 # dovolené napětí v ohybu
    B["tauek"] = B["Re"] * 0.23 # mez únavy v krutu
    B["taudk"] = B["Re"] * 0.25 # dovolené napětí v krutu
    B["pd"] = B["Re"] * 0.8 # dovolené napětí na otlačení
  end
  if haskey(B, "sigmadt")
    B["taudk"] = B["sigmadt"] * 0.6
  end

  C = "Materiál: " * (get(B, "CSN", get(B, "znacka", A)))

  if tisk
    println("--- Material info ---")
    for (k,v) in sort(collect(B))
      println("$k = $v")
    end
  end

  return B, C
end
## Funkce Julia
###############################################################
## Popis funkce:
#
# ver: 2025-12-04
## Funkce: nazev_funkce()
#
## Vzor:
## vystupni_promenne = nazev_funkce(vstupni_promenne)
## Vstupní proměnné:
#
## Výstupní proměnné:
#
## Použité balíčky
#
## Použité uživatelské funkce:
#
## Příklad:
#
###############################################################
## Použité proměnné vnitřní:
#
using Unitful, Unitful.DefaultSymbols
using Printf: @sprintf

function namahanitah(; F=nothing, S=nothing, sigmaDt=nothing, 
    E=nothing, Re=nothing, L0=nothing, mat=nothing, 
    zatizeni::AbstractString="statický", profil=nothing, 
    tvar=nothing, return_text::Bool=true)

    # pomocné
    hasq(x) = x !== nothing && x !== missing && isa(x, 
    Unitful.AbstractQuantity)
    isnum(x) = x !== nothing && isa(x, Number)
    attach_unit(x, u) = isa(x, Unitful.AbstractQuantity) ? x : x * u

    # výchozí E (Young) — standardně 210 GPa
    E_default = 210u"GPa"

    # kontroly duplicity volby S/profil/tvar a sigmaDt/mat
    cntS = (S !== nothing ? 1 : 0) + (profil !== nothing ? 1 : 0) + 
    (tvar !== nothing ? 1 : 0)
    if cntS > 1
        error("Zadejte pouze jednu z hodnot: S, profil nebo tvar.")
    end
    if (sigmaDt !== nothing) && (mat !== nothing)
        error("Zadejte pouze jednu z hodnot: sigmaDt nebo mat.")
    end

    # doplnění jednotek pro číselné vstupy
    if F !== nothing
        if isnum(F)
            F = attach_unit(F, u"N")
        elseif !hasq(F)
            error("Neznámý formát F: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if S !== nothing
        if isnum(S)
            S = attach_unit(S, u"mm^2")   # mm^2, později převedeme dle potřeby
        elseif !hasq(S)
            error("Neznámý formát S: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if sigmaDt !== nothing
        if isnum(sigmaDt)
            sigmaDt = attach_unit(sigmaDt, u"MPa")
        elseif !hasq(sigmaDt)
            error("Neznámý formát sigmaDt: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if Re !== nothing
        if isnum(Re)
            Re = attach_unit(Re, u"MPa")
        elseif !hasq(Re)
            error("Neznámý formát Re: očekávám číslo nebo Unitful.Quantity")
        end
    end

    if E !== nothing
        if isnum(E)
            E = attach_unit(E, u"GPa")
        elseif !hasq(E)
            error("Neznámý formát E: očekávám číslo nebo Unitful.Quantity")
        end
    else
        E = E_default
    end

    if L0 !== nothing
        if isnum(L0)
            L0 = attach_unit(L0, u"mm")
        elseif !hasq(L0)
            error("Neznámý formát L0: očekávám číslo nebo Unitful.Quantity")
        end
    end

    # pokud je zadán materiál, pokusíme se získat Re/E z materialy(mat)
    if mat !== nothing
        if !isa(mat, AbstractString)
            error("Argument 'mat' musí být řetězec s názvem materiálu.")
        end
        # očekáváme, že uživatel má definovanou funkci materialy(mat::String)
        if !isdefined(Main, :materialy)
            error("Funkce `materialy(mat)` není definována v Main. Definujte ji nebo neposílejte 'mat'.")
        end
        matinfo = materialy(mat) # očekává Dict nebo objekt s poli :Re a :E (Unitful)
        if haskey(matinfo, :Re)
            Re = matinfo[:Re]
        end
        if haskey(matinfo, :E)
            E = matinfo[:E]
        end
    end

    # pokud je zadané Re -> spočítat sigmaDt pomocí dovoleneNapeti
    if Re !== nothing
        if !isdefined(Main, :dovoleneNapeti)
            error("Funkce `dovoleneNapeti(Re, typ, zatizeni)` není definována v Main, ale 'Re' byl zadán.")
        end
        sigmaDt = dovoleneNapeti(Re, "tah", zatizeni)
    end

    # pokud je zadán profil/tvar, zavolat externí funkce, aby dodaly S (a text)
    S_text = ""
    if profil !== nothing
        if !isdefined(Main, :profil)
            error("Funkce `profil(...)` není definována, ale 'profil' byl zadán.")
        end
        # očekáváme, že profil(profilname, "S") vrátí Dict(:S => quantity)
        p = profil(profil)
        if haskey(p, :S)
            S = p[:S]
        else
            error("profil(...) neobsahuje pole :S")
        end
    elseif tvar !== nothing
        if !isdefined(Main, :tvar)
            error("Funkce `tvar(...)` není definována, ale 'tvar' byl zadán.")
        end
        tv = tvar(tvar)
        if haskey(tv, :S)
            S = tv[:S]
        else
            error("tvar(...) neobsahuje pole :S")
        end
        if haskey(tv, :S_str)
            S_text = tv[:S_str]
        end
    end

    # finální kontrola, že máme F, S a sigmaDt
    if F === nothing
        error("Chybí zatěžující síla F.")
    end
    if S === nothing
        error("Chybí plocha S (nebo profil / tvar).")
    end
    if sigmaDt === nothing
        error("Chybí sigmaDt (dovolené napětí) — zadejte 'sigmaDt' nebo 'Re' či 'mat'.")
    end

    # výpočet: sigma = F / S -> převod na MPa
    sigma = F / S
    sigma_mpa = uconvert(u"MPa", sigma)

    # součinitel bezpečnosti k = sigmaDt / sigma (oba v MPa)
    sigmaDt_mpa = uconvert(u"MPa", sigmaDt)
    k = sigmaDt_mpa / sigma_mpa      # je to Unitful.Quantity bez jednotky

    # epsilon = sigma / E  (bez jednotky)
    # uconvert E na stejnou jednotku jako sigma (MPa -> GPa případně), ale raději převedeme sigma do Pa a E do Pa
    E_pa = uconvert(u"Pa", E)
    sigma_pa = uconvert(u"Pa", sigma)
    epsilon = sigma_pa / E_pa  # bez jednotky

    # deltaL a L pokud L0 zadané
    deltaL = nothing
    L = nothing
    if L0 !== nothing
        # epsilon je bez jednotky, L0 má jednotku mm — deltaL má jednotku mm
        deltaL = epsilon * L0
        L = L0 + deltaL
    end

    # verdict podle k
    verdict = if k >= 1.5
        "Spoj je bezpečný"
    elseif k >= 1.0
        "Spoj je na hranici bezpečnosti"
    else
        "Spoj není bezpečný!"
    end

    # připravíme výstupní dict (VV)
    VV = Dict{Symbol,Any}()
    VV[:info] = "namáhání v tahu"
    VV[:zatizeni] = zatizeni
    VV[:F] = F
    VV[:F_info] = "Zatěžující síla"
    VV[:S] = S
    VV[:S_text] = S_text
    VV[:S_info] = "Plocha průřezu profilu"
    VV[:sigmaDt] = sigmaDt
    VV[:sigmaDt_info] = "Dovolené napětí v tahu"
    VV[:sigma] = sigma_mpa
    VV[:sigma_info] = "Napětí v tahu"
    VV[:epsilon] = epsilon
    VV[:epsilon_info] = "Poměrné prodloužení"
    VV[:bezpecnost] = k
    VV[:bezpecnost_info] = "Součinitel bezpečnosti"
    VV[:verdict] = verdict
    VV[:verdict_info] = "Bezpečnost spoje"
    VV[:E] = E
    VV[:E_info] = "Modul pružnosti v tahu, Youngův modul"
    VV[:Re] = Re
    VV[:Re_info] = "Mez kluzu"
    VV[:mat] = mat
    VV[:mat_info] = "Materiál"
    VV[:L0] = L0
    VV[:L0_info] = "Délka namáhaného profilu"
    VV[:deltaL] = deltaL
    VV[:deltaL_info] = deltaL === nothing ? "" : "Skutečné prodloužení"
    VV[:L] = L
    VV[:L_info] = L === nothing ? "" : "Délka po prodloužení"
    VV[:profil] = profil === nothing ? "" : profil
    VV[:profil_info] = "Tvar profilu"

    if return_text
        Dispstr = namahanitahtext(VV)
        return VV, Dispstr
    else
        return VV
    end
end

# pomocná funkce pro formátování výstupu (podobná MATLAB verzi)
function namahanitahtext(VV::Dict{Symbol,Any})
    lines = String[]
    push!(lines, "Výpočet $(VV[:info])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "materiál: $(VV[:mat] === nothing ? "" : string(VV[:mat]))")
    push!(lines, "profil: $(VV[:profil])")
    push!(lines, "zatížení: $(VV[:zatizeni])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "zadání:")

    # F
    if VV[:F] !== nothing
        Fval = uconvert(u"N", VV[:F])
        push!(lines, @sprintf(
            "F = %g %s   %s",
            ustrip(u"N", Fval), "N", VV[:F_info]
        ))
    end

    # S
    if VV[:S] !== nothing
        Sval = uconvert(u"mm^2", VV[:S])
        if VV[:S_text] != ""
            push!(lines, @sprintf(
                "S = %s = %g %s   %s",
                VV[:S_text],
                ustrip(u"mm^2", Sval), "mm^2",
                VV[:S_info]
            ))
        else
            push!(lines, @sprintf(
                "S = %g %s   %s",
                ustrip(u"mm^2", Sval), "mm^2",
                VV[:S_info]
            ))
        end
    end

    # sigmaDt
    if VV[:sigmaDt] !== nothing
        sd = uconvert(u"MPa", VV[:sigmaDt])
        push!(lines, @sprintf(
            "sigmaDt = %g %s   %s",
            ustrip(u"MPa", sd), "MPa", VV[:sigmaDt_info]
        ))
    end

    # L0
    if VV[:L0] !== nothing
        L0v = uconvert(u"mm", VV[:L0])
        push!(lines, @sprintf(
            "L0 = %g %s   %s",
            ustrip(u"mm", L0v), "mm", VV[:L0_info]
        ))
    end

    # Re
    if VV[:Re] !== nothing
        Rv = uconvert(u"MPa", VV[:Re])
        push!(lines, @sprintf(
            "Re = %g %s   %s",
            ustrip(u"MPa", Rv), "MPa", VV[:Re_info]
        ))
    end

    # E
    if VV[:E] !== nothing
        Ev = uconvert(u"GPa", VV[:E])
        push!(lines, @sprintf(
            "E = %g %s   %s",
            ustrip(u"GPa", Ev), "GPa", VV[:E_info]
        ))
    end

    push!(lines, "----------------------------------------------------------------")
    push!(lines, "výpočet:")

    # sigma
    s = uconvert(u"MPa", VV[:sigma])
    push!(lines, @sprintf(
        "sigma = %g %s   %s",
        ustrip(u"MPa", s), "MPa", VV[:sigma_info]
    ))

    # epsilon
    eps = VV[:epsilon]
    push!(lines, @sprintf(
        "epsilon = %g = %g %%   %s",
        eps,
        eps * 100,
        VV[:epsilon_info]
    ))

    # deltaL
    if VV[:deltaL] !== nothing
        dl = uconvert(u"mm", VV[:deltaL])
        push!(lines, @sprintf(
            "deltaL = %g %s   %s",
            ustrip(u"mm", dl), "mm", VV[:deltaL_info]
        ))
    end

    # L
    if VV[:L] !== nothing
        L = uconvert(u"mm", VV[:L])
        push!(lines, @sprintf(
            "L = %g %s   %s",
            ustrip(u"mm", L), "mm", VV[:L_info]
        ))
    end

    # bezpečnost
    k = VV[:bezpecnost]
    push!(lines, @sprintf(
        "k = %g   %s\n%s:  %s",
        ustrip(k),
        VV[:bezpecnost_info],
        VV[:verdict_info],
        VV[:verdict]
    ))

    return join(lines, "\n")
end
## Funkce Julia
###############################################################
## Popis funkce:
# Vrátí vlastnosti hledaného materiálu dle tabulky
# ver: 2025-11-21
## Funkce: materialy()
#
## Vzor:
## B, C = materialy(A)
## Vstupní proměnné:
# A - Hledaný materiál. [string]
## Výstupní proměnné:
# B - Pole hodnot, vlastností. [struct]
#  .E - Modul pružnosti v tahu, Youngův modul [GPa] [symunit]
#  .G - Modul pružnosti v krutu [GPa] [symunit]
#  .Re - Mez kluzu [MPa] [symunit]
#  .Rm - Mez pevnosti [MPa] [symunit]
#  .sigmae -  Mez únavy v tahu/tlaku [MPa] [symunit]
#  .sigmadt -  Dovolené napětí v tahu [MPa] [symunit]
#  .sigmadk -  Dovolené napětí v tlaku [MPa] [symunit]
#  .taues -  Mez únavy ve smyku [MPa] [symunit]
#  .tauds -  Dovolené napětí ve smyku - střihu [MPa] [symunit]
#  .taueo -  Mez únavy v ohybu [MPa] [symunit]
#  .taudo -  Dovolené napětí v ohybu [MPa] [symunit]
#  .tauek -  Mez únavy v krutu [MPa] [symunit]
#  .taudk -  Dovolené napěti v krutu [MPa] [symunit]
#  .pd - Dovolené napětí na otlačení [MPa] [symunit]
#  .rho - Hustota materiálu [[kg]/[m]^3] [symunit]
#  .alfa - Koeficient tepelné lineární roztažnosti [1/[Celsius] [symunit]
# C - Výpis hodnot char
## Použité balíčky
# SpravaSouboru, Unitful
## Použité uživatelské funkce:
# sprdsheet2velkst(), sprsheetRef(), sprsheet2tabl()
## Příklad:
# B, C = materialy("11 373")
#   vrátí vlastnosti materiálu dle ČSN 11 373 (ocel S235JR)
# B["E"]
#      => 210 GPa
# B["Re"]
#      => 235 MPa
# B["sigmae"]
#      => 94 MPa
# B["sigmadt"]
#      => 188 MPa
# C
#      => "Materiál: 11 373"


###############################################################
## Použité proměnné vnitřní:
#
using SpravaSouboru, Unitful

function materialy(A::AbstractString; tisk::Bool=false)
    cesta01 = dirname(@__FILE__)
    podslozka = "materialy"
    soubor1 = "materialy.ods"
    souborDat = "materialy.jld2"
    listname = "material"
    STRTradk = 3

    # zjištění rozsahu listu
    rozsah = sprdsheet2velkst(joinpath(cesta01, podslozka, soubor1), listname)
    koncova_adresa = last(split(rozsah, ':'))
    W1 = sprsheetRef(koncova_adresa)
    W1_nova = sprsheetRef([STRTradk, W1[2]])
    rozsahNadpis = "A$(STRTradk):$W1_nova"
    rozsahTabulka = "A5:$koncova_adresa"

    # načtení tabulky
    hdr_mat, _, raw_tbl = sprsheet2tabl(
        joinpath(cesta01, podslozka),
        [soubor1, souborDat],
        listname,
        [rozsahNadpis, rozsahNadpis, rozsahTabulka]
    )
    headers = vec(hdr_mat)

    # sanitizace hlaviček
    function sanitize_header(s)
        s2 = replace(string(s), r"\s+" => "_")
        s2 = replace(s2, r"[^A-Za-z0-9_]" => "_")
        if isempty(s2)
            s2 = "col"
        end
        if occursin(r"^[0-9]", s2)
            s2 = "_" * s2
        end
        return Symbol(s2)
    end
    col_syms = [sanitize_header(h) for h in headers]

    # převod tabulky
    if ndims(raw_tbl) == 1
        raw_tbl = reshape(raw_tbl, :, 1)
    end
    nrows, ncols = size(raw_tbl)
    cols = [raw_tbl[:, j] for j in 1:ncols]
    TBL = (; Pair.(col_syms, cols)...)

    # hledání materiálu podle zadaného označení
    function find_row_by_value(vec, val)
        for (i, x) in enumerate(vec)
            xs = lowercase(replace(string(x), " " => ""))
            if xs == lowercase(replace(val, " " => ""))
                return i
            end
        end
        return nothing
    end

    row = nothing
    for key in (:CSN, :ISO, :DIN, :EN, :znacka)
        if haskey(TBL, key)
            r = find_row_by_value(TBL[key], A)
            if r !== nothing
                row = r
                break
            end
        end
    end
    if row === nothing
        error("Zadaný materiál '$A' nebyl nalezen.")
    end

    # vytvoření slovníku výsledků
    B = Dict{String, Any}()

    function set_if_present(sym, name)
        if haskey(TBL, sym)
            val = TBL[sym][row]
            if !(ismissing(val) || isempty(string(val)))
                B[name] = val
            end
        end
    end

    # přenos hodnot
    for s in (
        :CSN, :ISO, :DIN, :EN, :znacka, :ny,
        :E, :G, :Re, :Rm, :rho, :alfa,
        :popis, :stav
    )
        set_if_present(s, string(s))
    end

    # převod na fyzikální jednotky
    function try_number(x)
        try
            return parse(Float64, string(x))
        catch
            return x
        end
    end

    for (key, unit) in [
        ("E", u"GPa"),
        ("G", u"GPa"),
        ("Re", u"MPa"),
        ("Rm", u"MPa"),
        ("rho", u"kg/m^3"),
        ("alfa", u"1/K")
    ]
        if haskey(B, key) && try_number(B[key]) isa Real
            B[key] = try_number(B[key]) * unit
        end
    end

    # odvozené hodnoty
    if haskey(B, "Rm") && !haskey(B, "Re")
        B["sigmae"] = B["Rm"] * 0.4 # mez únavy v tahu/tlaku
        B["taues"]  = B["Rm"] * 0.23 # mez únavy ve smyku
        B["tauek"]  = B["Rm"] * 0.23
        B["taueo"]  = B["Rm"] * 0.4
    end
    if haskey(B, "Re")
        B["sigmadt"] = B["Re"] * 0.8 # dovolené napětí v tahu
        B["sigmadk"] = B["Re"] * 0.8
        B["tauds"]   = B["Re"] * 0.25
        B["taudo"]   = B["Re"] * 0.4
        B["taueo"]   = B["Re"] * 0.4
        B["pd"]      = B["Re"] * 0.8
        B["taudk"]   = B["Re"] * 0.25
        B["taues"]   = B["Re"] * 0.23
        B["tauek"]   = B["Re"] * 0.23
    end

    # popisek
    C = "Materiál: " * (get(B, "CSN", get(B, "znacka", A)))

    # výpis
    if tisk
        println("─── Informace o materiálu ───")
        for (k, v) in sort(collect(B))
            if v isa Quantity
                println(rpad(k, 12), " = ", round(uconvert(unit(v), v); sigdigits=5))
            else
                println(rpad(k, 12), " = ", v)
            end
        end
        println("──────────────────────────────")
    end

    return B, C
end
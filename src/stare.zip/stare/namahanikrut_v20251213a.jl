## Funkce Julia
###############################################################
## Popis funkce:
# Výpočet namáhání v krutu pro strojní součásti.
# ver: 2025-12-13
## Funkce: namahanikrut()
#
## Vzor:
## vystupni_promenne = namahanikrut(vstupni_promenne)
## Vstupní proměnné:
# Mk - krouticí moment s jednotkou (N*m)
# Wk - průřezový modul v krutu s jednotkou (mm³)
# Ip - polární moment setrvačnosti s jednotkou (mm⁴), volitelný (pro výpočet úhlu zkroucení)
# tauDk - dovolené smykové napětí v krutu s jednotkou (MPa)
# G - smykový modul materiálu s jednotkou (GPa), volitelný (pro výpočet úhlu zkroucení)
# E - Youngův modul materiálu s jednotkou (GPa), volitelný (pokud není G zadáno)
# Re - mez kluzu materiálu s jednotkou (MPa), volitelný (pro výpočet tauDk)
# L0 - délka součásti pro výpočet úhlu zkroucení s jednotkou (mm), volitelný
# mat - materiál jako řetězec (název materiálu) nebo Dict s vlastnostmi materiálu, volitelný
# zatizeni - způsob zatížení jako řetězec: "statický", "pulzní", "dynamický", "rázový" (výchozí: "statický")
# profil - název profilu jako řetězec (pro získání Wk, Ip, S), volitelný
# return_text - logická hodnota, zda vrátit i textový výstup (výchozí: true)
## Výstupní proměnné:
# VV - slovník (Dict) s výsledky výpočtu
# txt - textový výstup s popisem výpočtu (pokud return_text=true)
## Použité balíčky
# Unitful, Unitful.DefaultSymbols, Printf
## Použité uživatelské funkce:
# dovoleneNapeti(), tvarprofilu(), materialy()
## Příklad:
#
###############################################################
## Použité proměnné vnitřní:
#
using Unitful, Unitful.DefaultSymbols
using Printf: @sprintf

function namahanikrut(; Mk=nothing, Wk=nothing, Ip=nothing, 
    S=nothing, tauDk=nothing, G=nothing, E=nothing, Re=nothing,
        L0=nothing, mat=nothing, zatizeni::AbstractString="statický",
        profil=nothing, return_text::Bool=true)

    # --- pomocné ---
    hasq(x) = x !== nothing && x !== missing && isa(x, Unitful.AbstractQuantity)
    isnum(x) = x !== nothing && isa(x, Number)
    attach_unit(x, u) = isa(x, Unitful.AbstractQuantity) ? x : x * u

    # výchozí
    G_default = 81u"GPa" # požadujeme G nebo mat

    # kontrola duplicity: Wk/Ip/S/profil
    cntGeom = (Wk !== nothing ? 1 : 0) + (Ip !== nothing ? 1 : 0) + (profil !== nothing ? 1 : 0)
    # žádný restriktivní error zde — uživatel může zadat jen Mk a Wk atd.
    # ale pokud zadá profil + manuální Wk/Ip, přebere explicitní hodnoty (priorita: explicitní args)

    # kontrola tauDk vs mat/Re
    if (tauDk !== nothing) && (mat !== nothing) && (Re !== nothing)
        # není chyba, ale dáváme přednost explicitnímu tauDk
    end

    # --- jednotky a převody vstupů ---
    # ---------------------------------
    if Mk !== nothing
        if isnum(Mk)
            Mk = attach_unit(Mk, u"N*m") # převod na N*m
        elseif !hasq(Mk) && !(isa(Mk, Unitful.AbstractQuantity))
            error("Mk musí být číslo nebo Unitful.Quantity (N*m).")
        end
    end

    if Wk !== nothing
        if isnum(Wk)
            Wk = attach_unit(Wk, u"mm^3") # převod na mm^3
        elseif !hasq(Wk)
            error("Wk musí být číslo nebo Unitful.Quantity (mm^3).")
        end
    end

    if Ip !== nothing
        if isnum(Ip)
            Ip = attach_unit(Ip, u"mm^4") # převod na mm^4
        elseif !hasq(Ip)
            error("Ip musí být číslo nebo Unitful.Quantity (mm^4).")
        end
    end

    if tauDk !== nothing
        if isnum(tauDk)
            tauDk = attach_unit(tauDk, u"MPa") # převod na MPa
        elseif !hasq(tauDk)
            error("tauDk musí být číslo nebo Unitful.Quantity (MPa).")
        end
    end

    if G !== nothing
        if isnum(G)
            G = attach_unit(G, u"GPa") # převod na GPa
        elseif !hasq(G)
            error("G musí být číslo nebo Unitful.Quantity (GPa).")
        end
    else
        G = G_default
    end

    if E !== nothing
        if isnum(E)
            E = attach_unit(E, u"GPa") # převod na GPa
        elseif !hasq(E)
            error("E musí být číslo nebo Unitful.Quantity (GPa).")
        end
    end

    if Re !== nothing
        if isnum(Re)
            Re = attach_unit(Re, u"MPa") # převod na MPa
        elseif !hasq(Re)
            error("Re musí být číslo nebo Unitful.Quantity (MPa).")
        end
    end

    if L0 !== nothing
        if isnum(L0)
            L0 = attach_unit(L0, u"mm") # převod na mm
        elseif !hasq(L0)
            error("L0 musí být číslo nebo Unitful.Quantity (mm).")
        end
    end

    # --- materiál ---
    # ----------------
    matinfo = Dict{Symbol,Any}()
    if mat !== nothing
        if !isa(mat, AbstractString)
            error("Argument 'mat' musí být řetězec.")
        end
        if !isdefined(Main, :materialy)
            error("Funkce materialy(mat) není definována v Main.")
        end
        raw = materialy(mat)
        if isa(raw, Tuple) && length(raw) == 2
            matinfo, _ = raw
        elseif isa(raw, Dict)
            matinfo = raw
        else
            error("materialy(mat) musí vracet Dict nebo (Dict, String).")
        end

        haskey(matinfo, :Re) && (Re = matinfo[:Re]) # mez kluzu
        haskey(matinfo, :G)  && (G  = matinfo[:G]) # smykový modul
        # nu (Poissonovo číslo) pokud je dostupné
        # očekáváme že matinfo může obsahovat :nu
    end

    # pokud Re zadané → dopočítat tauDk přes dovoleneNapeti
    if Re !== nothing && tauDk === nothing
        if !isdefined(Main, :dovoleneNapeti)
            error("Funkce dovoleneNapeti není definována v Main.")
        end
        # očekáváme, že dovoleneNapeti podporuje typ "krut"
        tauDk = dovoleneNapeti(Re, "krut", zatizeni)
    end

    # --- profil: vyžádat Wk, Ip, S pokud profil zadán a chybí konkrétní hodnoty ---
    profil_info = Dict{Symbol,Any}()
    if profil !== nothing
        if !isdefined(Main, :tvarprofilu)
            error("Funkce tvarprofilu(...) není definována.")
        end
        # požadujeme Wk, Ip — ale pokud už má uživatel některou z nich explicitně, tu použijeme
        reqs = String[]
        # zavolat tak, aby tvarprofilu vrátil požadované veličiny
        tv = tvarprofilu(profil, "Wk", "Ip")
        # převzetí, pokud chybí explicitní hodnoty
        if Wk === nothing && haskey(tv, :Wk)
            Wk = tv[:Wk] # převzetí z profilu
        end
        if Ip === nothing && haskey(tv, :Ip)
            Ip = tv[:Ip] # převzetí z profilu
        end
        # Wk_str/Ip_str
        if haskey(tv, :Wk_str)
            profil_info[:Wk_str] = tv[:Wk_str] # převzetí textového popisu
        end
        if haskey(tv, :Ip_str)
            profil_info[:Ip_str] = tv[:Ip_str] # převzetí textového popisu
        end
        # ostatní rozměry (a,b,t,...)
        for k in keys(tv)
            if k ∉ (:Wk, :Wk_str, :Ip, :Ip_str)
                profil_info[k] = tv[k] # převzetí dalších rozměrů
            end
        end
    end

    # --- validace vstupů ---
    # -----------------------
    if Mk === nothing
        error("Chybí krouticí moment Mk.")
    end
    if Wk === nothing
        error("Chybí průřezový modul v krutu Wk (nebo profil, který ho poskytne).")
    end
    if Ip === nothing && L0 !== nothing
        # Ip je nutné pro výpočet úhlu; pokud L0 nezadáno, phi nebude počítáno
        # pouze varování, ne error
        # (ponecháme bez erroru)
        nothing
    end
    if tauDk === nothing
        error("Chybí tauDk (dovolené smykové napětí) — zadejte tauDk nebo Re/mat.")
    end

    # --- zajištění jednotek pro výpočty ---
    # Mk -> N*m (pro úhel) a použití Mk/Wk -> MPa
    Mk_nm = uconvert(u"N*m", Mk)
    # Wk : mm^3 (pro tau = Mk / Wk -> N/m^2 after unit conv). Mk must be N*mm or N*m; using uconvert below handles it.

    # --- výpočty ---
    # smykové napětí v krutu: tau = Mk / Wk  (převod na MPa)
    # Mk/Wk -> (N*m)/(mm^3) gives N*m/mm^3 = N/mm^2 * (m/mm) ...  jednoduše použijeme jednotky Unitful:
    # převedeme Mk na N*mm a poté vydělíme Wk (mm^3) -> N/mm^2 = MPa
    Mk_Nmm = uconvert(u"N*mm", Mk)
    tau_q = Mk_Nmm / uconvert(u"mm^3", Wk)    # Unitful quantity N/mm^2
    tau = uconvert(u"MPa", tau_q)

    # bezpečnost k = tauDk / tau
    tauDk_mpa = uconvert(u"MPa", tauDk)
    k = tauDk_mpa / tau

    # výpočet úhlu zkroucení phi (radiány) pokud L0 a Ip a G dostupné
    phi = nothing    # skutečný úhel zkroucení [rad]
    theta = nothing  # poměrné zkroucení [rad/m]
    # skutečný úhel zkroucení phi [rad]
    if L0 !== nothing && Ip !== nothing
        # převody do SI
        Mk_SI = uconvert(u"N*m", Mk)
        L0_m = uconvert(u"m", L0)
        Ip_m4 = uconvert(u"m^4", Ip)
        G_Pa = uconvert(u"Pa", G)
        
        phi = (Mk * L0) / (G * Ip)
        phi = uconvert(u"rad", phi) # převod na radiany
    end
    # poměrné zkroucení theta [rad/m]
    if Ip !==nothing
        theta = Mk / (G * Ip)
        theta = uconvert(u"rad/m", theta) # převod na rad/m
    end
    verdict =   if k >= 1.5
                    "Spoj je bezpečný"
                elseif k >= 1.0
                    "Spoj je na hranici bezpečnosti"
                else
                    "Spoj není bezpečný!"
                end # konec if
    # pokud chceme převést phi na stupně, uživatel si to může udělat s rad2deg(phi)

    # --- připravíme výstupní dict ---
    VV = Dict{Symbol,Any}()
    VV[:info] = "namáhání v krutu"
    VV[:zatizeni] = zatizeni # způsob zatížení
    VV[:Mk] = Mk # krouticí moment
    VV[:Mk_info] = "Krouticí moment"
    VV[:Wk] = Wk # průřezový modul v krutu
    VV[:Wk_info] = "Průřezový modul v krutu"
    VV[:Wk_text] = get(profil_info, :Wk_str, "")
    VV[:Ip] = Ip # polární moment setrvačnosti
    VV[:Ip_info] = "Polární moment setrvačnosti"
    VV[:Ip_text] = get(profil_info, :Ip_str, "")
    VV[:tauDk] = tauDk # dovolené smykové napětí v krutu
    VV[:tauDk_info] = "Dovolené smykové napětí v krutu"
    VV[:tau] = tau # smykové napětí v krutu
    VV[:tau_info] = "Smykové napětí v krutu (τ)"
    VV[:phi] = phi # úhel zkroucení [rad]
    VV[:phi_deg] = phi === nothing ? nothing : phi * 180 / π # úhel zkroucení [deg]
    VV[:phi_info] = phi === nothing ? "" : "Úhel zkroucení"
    VV[:bezpecnost] = k # součinitel bezpečnosti
    VV[:bezpecnost_info] = "Součinitel bezpečnosti (τ_dov / τ)"
    VV[:verdict] =  verdict # textové hodnocení bezpečnosti spojení
    VV[:verdict_info] = "Bezpečnost spoje"
    VV[:G] = G # smykový modul
    VV[:G_info] = "Smykový modul (G)"
    VV[:E] = E # Youngův modul
    VV[:E_info] = "Youngův modul (E)"
    VV[:Re] = Re # mez kluzu
    VV[:Re_info] = "Mez kluzu"
    VV[:mat] = mat # materiál
    VV[:mat_info] = "Materiál"
    VV[:L0] = L0 # délka pro výpočet úhlu zkroucení
    VV[:L0_info] = "Délka pro výpočet zkroucení"
    VV[:theta] = theta # poměrné zkroucení [rad/m]
    VV[:theta_info] = theta === nothing ? "" : "Poměrné zkroucení"
    VV[:theta_deg] = theta === nothing ? nothing : theta * 180 / π # poměrné zkroucení [deg/m]
    VV[:theta_deg_info] = "Poměrné zkroucení (deg/m)"
    VV[:profil] = profil === nothing ? "" : profil
    VV[:profil_info] = profil_info # další info o profilu

    if return_text
        Dispstr = namahanikruttext(VV)
        return VV, Dispstr
    else
        return VV
    end
end


# --- textový výstup ---
function namahanikruttext(VV::Dict{Symbol,Any})
    lines = String[]
    push!(lines, "Výpočet $(VV[:info])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "materiál: $(VV[:mat] === nothing ? "" : string(VV[:mat]))")

    if VV[:profil] != ""
        push!(lines, "profil: $(VV[:profil])")
        # pokud chceš rozbalit rozměry, odkomentuj níže
        #for (k, v) in VV[:profil_info]
        #    if isa(v, Unitful.AbstractQuantity)
        #        v2 = try uconvert(u"mm", v) catch v end
        #        push!(lines, "  $(k) = $(v2)")
        #    else
        #        push!(lines, "  $(k) = $(v)")
        #    end
        #end
    end

    push!(lines, "zatížení: $(VV[:zatizeni])")
    push!(lines, "----------------------------------------------------------------")
    push!(lines, "zadání:")

    # Mk
    if VV[:Mk] !== nothing
        v = uconvert(u"N*m", VV[:Mk])
        push!(lines, @sprintf("Mk = %g N*m   %s", ustrip(u"N*m", v), VV[:Mk_info]))
    end

    # Wk
    if VV[:Wk] !== nothing
        v = uconvert(u"mm^3", VV[:Wk])
        if haskey(VV, :Wk_text) && VV[:Wk_text] != ""
            push!(lines, @sprintf("Wk = %s = %g mm^3   %s", VV[:Wk_text], ustrip(u"mm^3", v), VV[:Wk_info]))
        else
            push!(lines, @sprintf("Wk = %g mm^3   %s", ustrip(u"mm^3", v), VV[:Wk_info]))
        end
    end

    # Ip
    if VV[:Ip] !== nothing
        v = uconvert(u"mm^4", VV[:Ip])
        if haskey(VV, :Ip_text) && VV[:Ip_text] != ""
            push!(lines, @sprintf("Ip = %s = %g mm^4   %s", VV[:Ip_text], ustrip(u"mm^4", v), VV[:Ip_info]))
        else
            push!(lines, @sprintf("Ip = %g mm^4   %s", ustrip(u"mm^4", v), VV[:Ip_info]))
        end
    end

    # tauDk
    if VV[:tauDk] !== nothing
        v = uconvert(u"MPa", VV[:tauDk])
        push!(lines, @sprintf("tauDk = %g MPa   %s", ustrip(u"MPa", v), VV[:tauDk_info]))
    end

    # G, E
    if VV[:G] !== nothing
        gv = uconvert(u"GPa", VV[:G])
        push!(lines, @sprintf("G = %g GPa   %s", ustrip(u"GPa", gv), VV[:G_info]))
    end
    if VV[:E] !== nothing
        ev = uconvert(u"GPa", VV[:E])
        push!(lines, @sprintf("E = %g GPa   %s", ustrip(u"GPa", ev), VV[:E_info]))
    end

    push!(lines, "----------------------------------------------------------------")
    push!(lines, "výpočet:")

    # tau
    t = uconvert(u"MPa", VV[:tau])
    push!(lines, @sprintf("tau = %g MPa   %s", ustrip(u"MPa", t), VV[:tau_info]))

    # bezpečnost k
    k = VV[:bezpecnost] # součinitel bezpečnosti
    push!(lines, @sprintf("k = %g   %s\n%s:  %s", ustrip(k), VV[:bezpecnost_info], VV[:verdict_info], VV[:verdict]))

    # úhel zkroucení
    if VV[:phi] !== nothing
        push!(lines, @sprintf("phi = %g rad   %s", VV[:phi], VV[:phi_info]))
        if haskey(VV, :phi_deg) && VV[:phi_deg] !== nothing
            push!(lines, @sprintf("phi = %g deg   %s", VV[:phi_deg], VV[:phi_info]))
        end
    end
    # poměrné zkroucení
    if VV[:theta] !== nothing
        push!(lines, @sprintf("theta = %g   %s", VV[:theta], VV[:theta_info]))
        push!(lines, @sprintf("theta = %g deg   %s", VV[:theta_deg], VV[:theta_info]))
    end

    return join(lines, "\n")
end
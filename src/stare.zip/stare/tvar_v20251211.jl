## Funkce Julia
###############################################################
## Popis funkce:
# Funkce řeší textové označení tvaru profilu dle ČSN a vrací
# strukturu s rozměry. Volitelně lze zadat výpočet vlastností
# profilu (plocha, momenty setrvačnosti, průřezové moduly…).
# ver: 2025-12-10
## Funkce: tvar()
#
## Vzor:
## vystupni_promenne = tvar(vstupni_promenne)
## Vstupní proměnné:
# inputStr - Textové označení tvaru profilu dle ČSN.
#   Podporované tvary:
#   "PLO" - obdélníkový profil
#   "PLO _a_x_b_" - "PLO 20x10" - obdélníkový profil
#   "PLO _a_x_b_R_r_" - "PLO 20x10R3" - obdélníkový profil s rádiusem
#   "OBD" - obdélníkový profil
#   "OBD _a_x_b_" - "OBD 20x10" - obdélníkový profil
#   "OBD _a_x_b_R_r_" - "OBD 20x10R3" - obdélníkový profil s rádiusem
#   "KR" - kruhový profil
#   "KR _D_" - "KR 20" - kruhový profil
#   "TRKR" - trubkový kruhový profil
#   "TRKR _D_x_t_" - "TRKR 20x2" - trubkový kruhový profil
#   "4HR" - čtyřhranný profil
#   "4HR _a_" - "4HR 20" - čtyřhranný profil
#   "4HR _a_R_r_" - "4HR 20R3" - čtyřhranný profil s rádiusem
#   "4HR _a_x_b_" - "4HR 20x10" - čtyřhranný profil obdélníkový
#   "4HR _a_x_b_R_r_" - "4HR 20x10R3" - čtyřhranný profil obdélníkový s rá
#   "6HR" - šestihranný profil
#   "6HR _s_" - "6HR 20" - šestihranný profil
#   "TR4HR" - trubkový čtyřhranný profil
#   "TR4HR _a_x_b_x_t_" - "TR4HR 20x20x2" - trubkový čtyřhranný profil
#   "TR4HR _a_x_b_x_t_R_r_" - "TR4HR 20x20x2R3" - trubkový čtyřhranný profil s rádiusem
# args... - Volitelné názvy vlastností k výpočtu.
#   Např: "S", "Ix", "Iy", "Ip", "Wk", ...
## Výstupní proměnné:
# vystupni_promenne - Struktura (Dict) s rozměry profilu a
#   případně i s vypočtenými vlastnostmi.
## Použité balíčky
# Unitful, Unitful.DefaultSymbols
## Použité uživatelské funkce:
# tvarvlcn - Výpočet vlastností profilu dle zadaných rozměrů.
## Příklad:
# dims = tvar("PLO 20x10") # pouze rozměry
# println(dims[:a]) # => 20 mm
# println(dims[:b]) # => 10 mm
# dims = tvar("KR 30") # pouze rozměry
# dims = tvar("TRKR 50x5") # pouze rozměry
# dims = tvar("TRKR 100x10R3", "S", "Ix", "Iy") # rozměry + vlastnosti
# dims = tvar("4HR 25") # pouze rozměry
# dims = tvar("OBD 40x20") # pouze rozměry
# dims = tvar("6HR 15") # pouze rozměry
# dims = tvar("TR4HR 60x40x4") # pouze rozměry
# dims = tvar("PLO 20x10", "S", "Ix", "Iy") # rozměry + vlastnosti
# dims = tvar("TR4HR 50x30x5", "S", "Ix") # rozměry + vlastnosti U profilu
###############################################################
## Použité proměnné vnitřní:
#

using Unitful, Unitful.DefaultSymbols
#using Unitful: mm

"""
    tvar(inputStr, [hodnota1, hodnota2, ...])

Parse textové označení profilu podle ČSN a vrátí Dict s rozměry.
Volitelně vypočte vlastnosti (S, Ix, Iy, Ip, Wk...) pomocí tvarvlcn().
"""
function tvar(inputStr::AbstractString, args...)
    # -----------------------------------------------------------
    # 1) Normalizace vstupu
    # -----------------------------------------------------------
    clean = replace(strip(inputStr), r"\s+" => " ") # odstraní nadbytečné mezery
    parts = split(clean, " ") # rozdělí na profil a rozměry

    if length(parts) < 2
        error("Neplatný vstup: chybí rozměrová část.")
    end

    profile = uppercase(parts[1]) # první část je profil
    dimPart = parts[2] # zbytek je dimenzionální část (profil + rozměry)

    # Výsledná struktura jako Dict
    dims = Dict{Symbol,Any}()
    dims[:info] = profile

    # -----------------------------------------------------------
    # 2) Rozlišení podle profilu (standard dle ČSN)
    # -----------------------------------------------------------

    if profile == "PLO"
        # Očekává "20x10", "20x10R3"
        m = match(r"^(\d+)\s*x\s*(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro PLO. Očekává \"PLO 20x10\".")
        end
        dims[:a] = parse(Int, m.captures[1]) * mm # šířka
        dims[:b] = parse(Int, m.captures[2]) * mm # výška
        dims[:r] = 0mm  # bez rádiusu

    elseif profile == "KR"
        # Očekává "20"
        m = match(r"^(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro KR. Očekává \"KR 20\".")
        end
        D = parse(Int, m.captures[1])
        dims[:D] = D * mm # průměr

    elseif profile == "TRKR"
        # Očekává "20x2"
        m = match(r"^(\d+)\s*x\s*(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro TRKR. Očekává \"TRKR 20x2\".")
        end
        D = parse(Int, m.captures[1]) # vnější průměr
        t = parse(Int, m.captures[2]) # tloušťka stěny
        d = D - 2t # vnitřní průměr

        dims[:D] = D * mm # vnější průměr
        dims[:d] = d * mm # vnitřní průměr
        dims[:t] = t * mm # tloušťka stěny

    elseif profile == "4HR"
        # Očekává "20", "20x10", "20R3", "20x10R3"
        m = match(r"^(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro 4HR. Očekává \"4HR 20\".")
        end
        dims[:a] = parse(Int, m.captures[1]) * mm # strana čtyřhranu
        dims[:b] = parse(Int, m.captures[1]) * mm # strana čtyřhranu
        dims[:r] = 0mm  # bez rádiusu

    elseif profile == "OBD"
        # Očekává "20x10", "20x10R3"
        m = match(r"^(\d+)\s*x\s*(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro OBD. Očekává \"OBD 20x10\".")
        end
        dims[:a] = parse(Int, m.captures[1]) * mm # šířka
        dims[:b] = parse(Int, m.captures[2]) * mm # výška
        dims[:r] = 0mm  # bez rádiusu

    elseif profile == "6HR"
        # Očekává "20", "20R3"
        m = match(r"^(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro 6HR. Očekává \"6HR 20\".")
        end
        s = parse(Int, m.captures[1]) # strana šestihranu
        dims[:s] = s * mm # strana šestihranu
        dims[:a] = s * mm # vzdálenost mezi protilehlými stranami
        dims[:r] = 0mm  # bez rádiusu

    elseif profile == "TR4HR"
        # Očekává "20x20x2", "20x20x2R3"
        m = match(r"^(\d+)\s*x\s*(\d+)\s*x\s*(\d+)$", dimPart)
        if m === nothing
            error("Neplatný formát pro TR4HR. Očekává \"TR4HR 20x20x2\".")
        end
        dims[:a] = parse(Int, m.captures[1]) * mm # šířka
        dims[:b] = parse(Int, m.captures[2]) * mm # výška
        dims[:t] = parse(Int, m.captures[3]) * mm # tloušťka stěny
        dims[:r] = 0mm  # bez rádiusu (vnitřního rohu)

    else
        error("Neznámý tvar profilu: $profile") # nepodporovaný tvar
    end

    # -----------------------------------------------------------
    # 3) Bez dalších parametrů → vracíme pouze rozměry
    # -----------------------------------------------------------
    if length(args) == 0
        return dims # pouze rozměry
    end

    # -----------------------------------------------------------
    # 4) Pokud jsou zadány vlastnosti (S, Ix, Iy, Ip…), řeší tvarvlcn
    # -----------------------------------------------------------
    for property in args
        if !(property isa AbstractString || property isa Symbol)
            error("Název vlastnosti musí být String nebo Symbol.")
        end

        key = Symbol(property) # převod na Symbol

        hodnota, vzorec = tvarvlcn(dims, key) # volání výpočtu vlastnosti

        dims[key] = hodnota # uložíme hodnotu vlastnosti
        dims[Symbol(key, :_str)] = vzorec # uložíme vzorec jako string
    end

    return dims # vracíme rozměry + vlastnosti
end
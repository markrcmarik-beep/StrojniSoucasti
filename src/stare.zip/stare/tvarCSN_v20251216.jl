
using Unitful, Unitful.DefaultSymbols

"""
tvarCSN(inputStr::AbstractString) -> Dict{Symbol,Any}

Rozpozná textové označení profilu dle ČSN
(např. "TR4HR20x20x2", "PLO 20x10", "KR30")
a vrátí slovník s rozměry profilu.
"""
function tvarCSN(inputStr::AbstractString)

    # -----------------------------------------------------------
    # 1) Normalizace vstupu
    # -----------------------------------------------------------
    s = uppercase(strip(inputStr))
    s = replace(s, r"\s+" => "")   # odstranění všech mezer

    dims = Dict{Symbol,Any}()

    # -----------------------------------------------------------
    # 2) Rozpoznání profilu + rozměrů
    # -----------------------------------------------------------

    # ---------------- PLO / OBD ----------------
    if m = match(r"^(PLO|OBD)(\d+)X(\d+)$", s)
        profile, a, b = m.captures
        dims[:info] = profile
        dims[:a] = parse(Int, a) * mm
        dims[:b] = parse(Int, b) * mm
        dims[:r] = 0mm

    # ---------------- KR ----------------
    elseif m = match(r"^KR(\d+)$", s)
        dims[:info] = "KR"
        dims[:D] = parse(Int, m.captures[1]) * mm

    # ---------------- TRKR ----------------
    elseif m = match(r"^TRKR(\d+)X(\d+)$", s)
        D = parse(Int, m.captures[1])
        t = parse(Int, m.captures[2])

        @assert D > 2t "Neplatná trubka: D ≤ 2t"

        dims[:info] = "TRKR"
        dims[:D] = D * mm
        dims[:t] = t * mm
        dims[:d] = (D - 2t) * mm

    # ---------------- 4HR ----------------
    elseif m = match(r"^4HR(\d+)$", s)
        a = parse(Int, m.captures[1])
        dims[:info] = "4HR"
        dims[:a] = a * mm
        dims[:b] = a * mm
        dims[:r] = 0mm

    # ---------------- OBD obdélník ----------------
    elseif m = match(r"^4HR(\d+)X(\d+)$", s)
        dims[:info] = "4HR"
        dims[:a] = parse(Int, m.captures[1]) * mm
        dims[:b] = parse(Int, m.captures[2]) * mm
        dims[:r] = 0mm

    # ---------------- 6HR ----------------
    elseif m = match(r"^6HR(\d+)$", s)
        s1 = parse(Int, m.captures[1])
        dims[:info] = "6HR"
        dims[:s] = s1 * mm
        dims[:a] = s1 * mm
        dims[:r] = 0mm

    # ---------------- TR4HR ----------------
    elseif m = match(r"^TR4HR(\d+)X(\d+)X(\d+)$", s)
        a = parse(Int, m.captures[1])
        b = parse(Int, m.captures[2])
        t = parse(Int, m.captures[3])

        @assert a > 2t && b > 2t "Neplatný dutý profil: tloušťka je příliš velká"

        dims[:info] = "TR4HR"
        dims[:a] = a * mm
        dims[:b] = b * mm
        dims[:t] = t * mm
        dims[:r] = 0mm

    else
        error("Neznámé nebo nepodporované označení profilu: \"$inputStr\"")
    end

    return dims
end
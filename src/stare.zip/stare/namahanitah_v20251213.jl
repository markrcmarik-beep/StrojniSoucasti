## Funkce Julia
###############################################################
## Popis funkce:
# Výpočet namáhání v tahu pro strojní součásti.
# ver: 2025-12-13
## Funkce: namahanitah()
#
## Vzor:
## vystupni_promenne = namahanitah(vstupni_promenne)
## Vstupní proměnné:
# F - Zatěžující síla (Unitful.Quantity), povinné. Musí být v tahu (kladná hodnota).
# S - Plocha průřezu (Unitful.Quantity), povinné pokud není zadán profil
# sigmaDt - Dovolené napětí v tahu (Unitful.Quantity), povinné pokud není zadán mat
# E - Modul pružnosti v tahu, Youngův modul (Unitful.Quantity), volitelný, výchozí 210 GPa
# Re - Mez kluzu (Unitful.Quantity), volitelný, pokud je zadán mat
# L0 - Délka namáhaného profilu (Unitful.Quantity), volitelný
# mat - Materiál jako řetězec (název materiálu) nebo Dict s vlastnostmi materiálu, volitelný
# zatizeni - způsob zatížení jako řetězec: "statický", "pulzní", "dynamický", "rázový" (výchozí: "statický")
# profil - název profilu jako řetězec (pro získání S), volitelný
# return_text - Logická hodnota (Bool). Určuje, zda se má vrátit i
#     textový výpis výpočtu. Výchozí hodnota je true. Pokud je false,
#     vrací se pouze dict s výsledky.
## Výstupní proměnné:
# VV - Dict s výsledky výpočtu namáhání v tahu. Pole VV obsahují:
#   :info - Popis výpočtu
#   :zatizeni - Typ zatížení (statický, dynamický, rázový)
#   :F - Zatěžující síla (Unitful.Quantity)
#   :F_info - Popis pole F
#   :S - Plocha průřezu (Unitful.Quantity)
#   :S_text - Textový popis výpočtu S (je-li k dispozici)
#   :S_info - Popis pole S
#   :sigmaDt - Dovolené napětí v tahu (Unitful.Quantity)
#   :sigmaDt_info - Popis pole sigmaDt
#   :sigma - Skutečné napětí v tahu (Unitful.Quantity v MPa)
#   :sigma_info - Popis pole sigma
#   :epsilon - Poměrné prodloužení (bez jednotky)
#   :epsilon_info - Popis pole epsilon
#   :bezpecnost - Součinitel bezpečnosti k (bez jednotky)
#   :bezpecnost_info - Popis pole bezpecnost
#   :verdict - Závěr o bezpečnosti spoje (řetězec)
#   :verdict_info - Popis pole verdict
#   :E - Modul pružnosti v tahu, Youngův modul (Unitful.Quantity)
#   :E_info - Popis pole E
#   :Re - Mez kluzu (Unitful.Quantity)
#   :Re_info - Popis pole Re
#   :mat - Materiál (řetězec)
#   :mat_info - Popis pole mat
#   :L0 - Délka namáhaného profilu (Unitful.Quantity)
#   :L0_info - Popis pole L0
#   :deltaL - Skutečné prodloužení (Unitful.Quantity), je-li spočítané
#   :deltaL_info - Popis pole deltaL
#   :L - Délka po prodloužení (Unitful.Quantity), je-li spočítané
#   :L_info - Popis pole L
#   :profil - Tvar profilu (řetězec), jestli byl zadaný
#   :profil_info - Popis pole profil
# txt - Volitelně i textový výpis výpočtu. Je-li parametr 
#   return_text=true (výchozí). Pokud return_text=false, vrací 
#   se pouze VV.
## Použité balíčky
# Unitful, Unitful.DefaultSymbols, Printf (jen @sprintf)
## Použité uživatelské funkce:
# materialy, dovoleneNapeti, tvarprofilu
## Příklad:
# namahanitah(F=1000u"N", S=50u"mm^2", mat="11373")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
# namahanitah(F=2000, S=100, sigmaDt=150u"MPa", E=200u"GPa", L0=500u"mm", 
#   zatizeni="statický", profil="PLO 20x10")
#  vrátí dict s výsledky a textový výpis výpočtu
# ->
###############################################################
## Použité proměnné vnitřní:
#
using Unitful, Unitful.DefaultSymbols
using Printf: @sprintf

function namahanitah(; F=nothing, S=nothing, sigmaDt=nothing, 
    E=nothing, Re=nothing, L0=nothing, mat=nothing, 
    zatizeni::AbstractString="statický", profil=nothing, 
    return_text::Bool=true)

    # pomocné
    hasq(x) = x !== nothing && x !== missing && isa(x, Unitful.AbstractQuantity)
    isnum(x) = x !== nothing && isa(x, Number)
    attach_unit(x, u) = isa(x, Unitful.AbstractQuantity) ? x : x * u

    # výchozí E
    E_default = 210u"GPa"

    # kontroly duplicity S/profil
    cntS = (S !== nothing ? 1 : 0) + (profil !== nothing ? 1 : 0)
    if cntS > 1
        error("Zadejte pouze jednu hodnotu z: S nebo profil.")
    end

    if (sigmaDt !== nothing) && (mat !== nothing)
        error("Zadejte pouze sigmaDt nebo mat, ne obojí.")
    end

    # přiřazení jednotek
    if F !== nothing
        if isnum(F)
            F = attach_unit(F, u"N")
        elseif !hasq(F)
            error("F musí být číslo nebo Unitful.Quantity")
        end
    end

    if S !== nothing
        if isnum(S)
            S = attach_unit(S, u"mm^2")
        elseif !hasq(S)
            error("S musí být číslo nebo Unitful.Quantity")
        end
    end

    if sigmaDt !== nothing
        if isnum(sigmaDt)
            sigmaDt = attach_unit(sigmaDt, u"MPa")
        elseif !hasq(sigmaDt)
            error("sigmaDt musí být číslo nebo Unitful.Quantity")
        end
    end

    if Re !== nothing
        if isnum(Re)
            Re = attach_unit(Re, u"MPa")
        elseif !hasq(Re)
            error("Re musí být číslo nebo Unitful.Quantity")
        end
    end

    if E !== nothing
        if isnum(E)
            E = attach_unit(E, u"GPa")
        elseif !hasq(E)
            error("E musí být číslo nebo Unitful.Quantity")
        end
    else
        E = E_default
    end

    if L0 !== nothing
        if isnum(L0)
            L0 = attach_unit(L0, u"mm")
        elseif !hasq(L0)
            error("L0 musí být číslo nebo Unitful.Quantity")
        end
    end

    # materiál → Re a E
    if mat !== nothing
        if !isa(mat, AbstractString)
            error("Argument mat musí být String.")
        end
        if !isdefined(Main, :materialy)
            error("Funkce materialy(mat) není definována.")
        end

        matinfo_raw = materialy(mat)

        if isa(matinfo_raw, Tuple) && length(matinfo_raw) == 2
            matinfo, _ = matinfo_raw
        elseif isa(matinfo_raw, Dict)
            matinfo = matinfo_raw
        else
            error("materialy(mat) musí vracet Dict nebo (Dict, String).")
        end

        if haskey(matinfo, :Re)
            Re = matinfo[:Re]
        end
        if haskey(matinfo, :E)
            E = matinfo[:E]
        end
    end

    # pokud existuje Re → dopočítat sigmaDt
    if Re !== nothing
        if !isdefined(Main, :dovoleneNapeti)
            error("Funkce dovoleneNapeti není definována.")
        end
        sigmaDt = dovoleneNapeti(Re, "tah", zatizeni)
    end

    # ---------------------------------------------------------
    # profil (automatické volání tvarprofilu(profil, "S"))
    # ---------------------------------------------------------
    S_text = ""
    profil_info = Dict{Symbol,Any}()

    if profil !== nothing
        if !isdefined(Main, :tvarprofilu)
            error("Funkce tvarprofilu(...) není definována.")
        end

        tv = tvarprofilu(profil, "S")  # vynucení výpočtu S

        if !haskey(tv, :S)
            error("Funkce tvarprofilu(...) nevrací :S ani po zadání \"S\".")
        end

        S = tv[:S]
        if haskey(tv, :S_str)
            S_text = tv[:S_str]
        end

        for k in keys(tv)
            if k ∉ (:S, :S_str)
                profil_info[k] = tv[k]
            end
        end
    end

    # kontrola F, S, sigmaDt
    if F === nothing
        error("Chybí F.")
    end
    if S === nothing
        error("Chybí S (ani profil nebyl použit).")
    end
    if sigmaDt === nothing
        error("Chybí sigmaDt (nezadáno sigmaDt ani mat/Re).")
    end

    # výpočty
    sigma = F / S
    sigma_mpa = uconvert(u"MPa", sigma)

    sigmaDt_mpa = uconvert(u"MPa", sigmaDt)
    k = sigmaDt_mpa / sigma_mpa

    E_pa = uconvert(u"Pa", E)
    sigma_pa = uconvert(u"Pa", sigma)
    epsilon = sigma_pa / E_pa

    deltaL = nothing
    L = nothing
    if L0 !== nothing
        deltaL = epsilon * L0
        L = L0 + deltaL
    end

    verdict = if k >= 1.5
        "Spoj je bezpečný"
    elseif k >= 1.0
        "Spoj je na hranici bezpečnosti"
    else
        "Spoj není bezpečný!"
    end

    # ---------------------------------------------------------
    # VÝSTUPNÍ DICT
    # ---------------------------------------------------------
    VV = Dict{Symbol,Any}()
    VV[:info] = "namáhání v tahu"
    VV[:zatizeni] = zatizeni
    VV[:F] = F
    VV[:F_info] = "Zatěžující síla"

    VV[:S] = S
    VV[:S_text] = S_text
    VV[:S_info] = "Plocha průřezu"

    VV[:sigmaDt] = sigmaDt
    VV[:sigmaDt_info] = "Dovolené napětí"

    VV[:sigma] = sigma_mpa
    VV[:sigma_info] = "Skutečné napětí v tahu"

    VV[:epsilon] = epsilon
    VV[:epsilon_info] = "Poměrné prodloužení"

    VV[:bezpecnost] = k
    VV[:bezpecnost_info] = "Součinitel bezpečnosti"

    VV[:verdict] = verdict
    VV[:verdict_info] = "Bezpečnost spoje"

    VV[:E] = E
    VV[:E_info] = "Youngův modul"

    VV[:Re] = Re
    VV[:Re_info] = "Mez kluzu"

    VV[:mat] = mat
    VV[:mat_info] = "Materiál"

    VV[:L0] = L0
    VV[:L0_info] = "Počáteční délka"

    VV[:deltaL] = deltaL
    VV[:deltaL_info] = deltaL === nothing ? "" : "Skutečné prodloužení"

    VV[:L] = L
    VV[:L_info] = L === nothing ? "" : "Délka po deformaci"

    # doplnění profilU
    VV[:profil] = profil === nothing ? "" : profil
    VV[:profil_info] = profil_info

    if return_text
        Dispstr = namahanitahtext(VV)
        return VV, Dispstr
    else
        return VV
    end
end



# ---------------------------------------------------------
# TEXTOVÝ VÝPIS
# ---------------------------------------------------------
function namahanitahtext(VV::Dict{Symbol,Any})
    lines = String[]
    push!(lines, "Výpočet $(VV[:info])")
    push!(lines, "--------------------------------------------------------------")
    push!(lines, "materiál: $(VV[:mat] === nothing ? "" : string(VV[:mat]))")

    if VV[:profil] != ""
        push!(lines, "profil: $(VV[:profil])")
        #for (k, v) in VV[:profil_info]
        #    if isa(v, Unitful.AbstractQuantity)
        #        v2 = try uconvert(u"mm", v) catch v end
        #        push!(lines, "  $(k) = $(v2)")
        #    else
        #        push!(lines, "  $(k) = $(v)")
        #    end
        #end
    end

    push!(lines, "zatížení: $(VV[:zatizeni])")
    push!(lines, "--------------------------------------------------------------")
    push!(lines, "zadání:")

    # F
    if VV[:F] !== nothing
        Fv = uconvert(u"N", VV[:F])
        push!(lines, @sprintf("F = %g N   %s", ustrip(u"N", Fv), VV[:F_info]))
    end

    # S
    if VV[:S] !== nothing
        Sv = uconvert(u"mm^2", VV[:S])
        if VV[:S_text] != ""
            push!(lines, @sprintf("S = %s = %g mm²   %s",
                VV[:S_text], ustrip(u"mm^2", Sv), VV[:S_info]))
        else
            push!(lines, @sprintf("S = %g mm²   %s",
                ustrip(u"mm^2", Sv), VV[:S_info]))
        end
    end

    # sigmaDt
    if VV[:sigmaDt] !== nothing
        sd = uconvert(u"MPa", VV[:sigmaDt])
        push!(lines, @sprintf("sigmaDt = %g MPa   %s",
            ustrip(u"MPa", sd), VV[:sigmaDt_info]))
    end

    # L0
    if VV[:L0] !== nothing
        lv = uconvert(u"mm", VV[:L0])
        push!(lines, @sprintf("L0 = %g mm   %s", ustrip(u"mm", lv), VV[:L0_info]))
    end

    # Re
    if VV[:Re] !== nothing
        rv = uconvert(u"MPa", VV[:Re])
        push!(lines, @sprintf("Re = %g MPa   %s",
            ustrip(u"MPa", rv), VV[:Re_info]))
    end

    # E
    if VV[:E] !== nothing
        Ev = uconvert(u"GPa", VV[:E])
        push!(lines, @sprintf("E = %g GPa   %s",
            ustrip(u"GPa", Ev), VV[:E_info]))
    end

    push!(lines, "--------------------------------------------------------------")
    push!(lines, "výpočet:")

    # sigma
    s = uconvert(u"MPa", VV[:sigma])
    push!(lines, @sprintf("sigma = %g MPa   %s",
        ustrip(u"MPa", s), VV[:sigma_info]))

    # epsilon
    eps = VV[:epsilon]
    push!(lines, @sprintf("epsilon = %g = %g %%   %s",
        eps, eps*100, VV[:epsilon_info]))

    # deltaL
    if VV[:deltaL] !== nothing
        dL = uconvert(u"mm", VV[:deltaL])
        push!(lines, @sprintf("deltaL = %g mm   %s",
            ustrip(u"mm", dL), VV[:deltaL_info]))
    end

    # L
    if VV[:L] !== nothing
        Lv = uconvert(u"mm", VV[:L])
        push!(lines, @sprintf("L = %g mm   %s",
            ustrip(u"mm", Lv), VV[:L_info]))
    end

    # bezpečnost
    k = VV[:bezpecnost]
    push!(lines,
        @sprintf("k = %g   %s\n%s:  %s",
            ustrip(k),
            VV[:bezpecnost_info],
            VV[:verdict_info],
            VV[:verdict]
        )
    )

    return join(lines, "\n")
end